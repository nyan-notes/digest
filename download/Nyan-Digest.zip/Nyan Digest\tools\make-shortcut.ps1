# Creates the "Nyan Digest" shortcut on the desktop (run once per machine, after setting up .venv):
#   powershell -ExecutionPolicy Bypass -File tools\make-shortcut.ps1
$root = Split-Path -Parent $PSScriptRoot
$lnk = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Nyan Digest.lnk'
$s = (New-Object -ComObject WScript.Shell).CreateShortcut($lnk)
$s.TargetPath = "$root\.venv\Scripts\pythonw.exe"
$s.Arguments = '"' + "$root\scripts\app.py" + '"'
$s.WorkingDirectory = $root
$s.IconLocation = "$root\app\nyan-digest.ico,0"
$s.Description = 'Nyan Digest: turn videos into reads'
$s.Save()
"Created $lnk"
