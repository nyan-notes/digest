"""Draws app/nyan-digest.ico (and a 512 px PNG): a grey note with round cat ears and a play mark,
on a white rounded tile, like Nyan Notes' icon. Needs Pillow (dev only: pip install pillow)."""
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
S = 1024  # draw big, scale down for clean edges
GREY, WHITE, TILE = (63, 65, 71, 255), (255, 255, 255, 255), (255, 255, 255, 255)

img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(img)
d.rounded_rectangle([40, 40, S - 40, S - 40], radius=210, fill=TILE, outline=(214, 214, 219, 255), width=10)
# ears (round), then the note body on top, then the play mark
for cx in (370, 654):
    d.ellipse([cx - 92, 196, cx + 92, 380], fill=GREY)
d.rounded_rectangle([250, 280, 774, 850], radius=96, fill=WHITE, outline=GREY, width=56)
d.polygon([(445, 440), (640, 565), (445, 690)], fill=GREY)

out = ROOT / "app" / "nyan-digest.ico"
img.resize((256, 256), Image.LANCZOS).save(out, sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
img.resize((512, 512), Image.LANCZOS).save(ROOT / "app" / "nyan-digest.png")
print(out)
