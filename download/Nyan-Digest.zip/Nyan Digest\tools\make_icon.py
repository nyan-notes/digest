"""Draws app/nyan-digest.ico (and a 512 px PNG): the Nyan Notes mark (a grey page whose top edge has two cat ears,
on a white tile with a thin grey edge) with a white play mark instead of the lines. The ears use the exact path of
Nyan Notes' IconGen.cs (owner 2026-11-16: the first, round ears "looked like a mouse").
The same shape is the SVG in app/index.html. Needs Pillow (dev only: pip install pillow)."""
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
S = 1024           # drawn big, scaled down for clean edges
K = S / 64         # the path below is in a 64 x 64 box, like Nyan Notes'
GREY = (0x6b, 0x6e, 0x74, 255)


def bez(p0, p1, p2, p3, n=40):
    return [tuple((1 - t) ** 3 * a + 3 * (1 - t) ** 2 * t * b + 3 * (1 - t) * t ** 2 * c + t ** 3 * d
                  for a, b, c, d in zip(p0, p1, p2, p3)) for t in (i / n for i in range(1, n + 1))]


def arc(cx, cy, r, a0, a1, n=16):
    import math
    return [(cx + r * math.cos(math.radians(a0 + (a1 - a0) * i / n)), cy + r * math.sin(math.radians(a0 + (a1 - a0) * i / n)))
            for i in range(n + 1)]


note = [(17, 50), (17, 24)]
note += bez((17, 24), (17, 18), (18.5, 13.5), (21.5, 13.5))
note += bez((21.5, 13.5), (24.5, 13.5), (27, 18.5), (28.5, 20))
note += bez((28.5, 20), (31, 19.2), (33, 19.2), (35.5, 20))
note += bez((35.5, 20), (37, 18.5), (39.5, 13.5), (42.5, 13.5))
note += bez((42.5, 13.5), (45.5, 13.5), (47, 18), (47, 24))
note += [(47, 50)] + arc(44, 50, 3, 0, 90) + [(20, 53)] + arc(20, 50, 3, 90, 180)

img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
# the tile: white to #f3f3f2 top to bottom, thin grey edge
grad = Image.new("RGBA", (S, S))
gd = ImageDraw.Draw(grad)
for y in range(S):
    v = 255 - round(12 * y / S)
    gd.line([(0, y), (S, y)], fill=(v, v, 255 - round(13 * y / S), 255))
mask = Image.new("L", (S, S), 0)
ImageDraw.Draw(mask).rounded_rectangle([2 * K, 2 * K, S - 2 * K, S - 2 * K], radius=15 * K, fill=255)
img.paste(grad, (0, 0), mask)
d = ImageDraw.Draw(img)
d.rounded_rectangle([2 * K, 2 * K, S - 2 * K, S - 2 * K], radius=15 * K, outline=(0xc9, 0xcb, 0xcf, 255), width=round(1.2 * K))
d.polygon([(x * K, y * K) for x, y in note], fill=GREY)
# the play mark, white
tri = [(28.5, 31.5), (38.5, 38), (28.5, 44.5)]
d.polygon([(x * K, y * K) for x, y in tri], fill=(255, 255, 255, 255))

out = ROOT / "app" / "nyan-digest.ico"
img.resize((256, 256), Image.LANCZOS).save(out, sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
img.resize((512, 512), Image.LANCZOS).save(ROOT / "app" / "nyan-digest.png")
print(out)
