# Packs Nyan Digest into a zip to share. Run through make-zip.bat (double-click).
#   -For friend   the app only: no reads, no history, no personal notes
#   -For mine     for your other computer: the app plus your reads and history (Claude's project notes too)
# Never included: .venv (rebuilt by setup.bat), Whisper models (download themselves), config.json
# (the built-in defaults are the same, and leaving it out means an update never overwrites anyone's settings).
param([ValidateSet('friend', 'mine', '')][string]$For = '', [switch]$NoExplorer)  # -NoExplorer: used by publish-site.ps1
# (ASCII only in this file: Windows PowerShell 5.1 misreads other characters in scripts without a BOM.)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Add-Type -AssemblyName System.IO.Compression.FileSystem

if (-not $For) {
    Write-Host ''
    Write-Host '  Who is this zip for?' -ForegroundColor White
    Write-Host '    1  A friend: just the app (none of your reads or history)'
    Write-Host '    2  My other computer: the app plus my reads and history'
    $a = Read-Host '  Type 1 or 2'
    $For = if ($a.Trim() -eq '2') { 'mine' } else { 'friend' }
}

$app = @(
    'setup.bat', 'START HERE.txt', 'make-zip.bat', 'add.bat', 'run-queue.bat', 'watch-queue.bat',
    'requirements.txt', 'requirements-gpu.txt', '.claude\settings.json', '.gemini\settings.json'
)
$appDirs = @('scripts', 'app', 'styles', 'tools', '.claude\skills')
$mineExtra = @('CLAUDE.md', 'PLAN.md')

$stamp = Get-Date -Format 'yyyy-MM-dd'
$stage = Join-Path $env:TEMP "nyan-digest-zip-$PID"
$top = Join-Path $stage 'Nyan Digest'
if (Test-Path $stage) { Remove-Item -Recurse -Force $stage }
New-Item -ItemType Directory -Force -Path $top | Out-Null

function Put($rel) {
    $src = Join-Path $root $rel
    if (-not (Test-Path -LiteralPath $src)) { return }
    $dst = Join-Path $top $rel
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
    Copy-Item -LiteralPath $src -Destination $dst -Force
}
function PutDir($rel, [scriptblock]$keep = { $true }) {
    $base = Join-Path $root $rel
    if (-not (Test-Path -LiteralPath $base)) { return }
    Get-ChildItem -LiteralPath $base -Recurse -File | Where-Object {
        $_.FullName -notmatch '\\__pycache__\\' -and $_.Extension -ne '.pyc' -and $_.Extension -ne '.tmp' -and $_.Name -ne 'publish-site.ps1' -and (& $keep $_)
    } | ForEach-Object { Put ($_.FullName.Substring($root.Length + 1)) }
}

$app | ForEach-Object { Put $_ }
$appDirs | ForEach-Object { PutDir $_ }

if ($For -eq 'mine') {
    $mineExtra | ForEach-Object { Put $_ }
    PutDir 'reads' { param($f) $f.Name -notlike '_Queue.md*' }
    # history: each video's status, info and transcript (so "New version" works there too); no audio, video or frames
    Get-ChildItem -LiteralPath (Join-Path $root 'work') -Directory -ErrorAction SilentlyContinue | ForEach-Object {
        foreach ($n in 'status.json', 'meta.json', 'job.json', 'transcript.json', 'transcript.txt') {
            if (Test-Path -LiteralPath (Join-Path $_.FullName $n)) { Put ("work\" + $_.Name + "\" + $n) }
        }
    }
}

$outDir = Join-Path $root 'release'
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
$zip = Join-Path $outDir "NyanDigest-$stamp-$For.zip"
if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip -Force }
[System.IO.Compression.ZipFile]::CreateFromDirectory($stage, $zip, [System.IO.Compression.CompressionLevel]::Optimal, $false)
$count = (Get-ChildItem -LiteralPath $top -Recurse -File).Count
Remove-Item -Recurse -Force $stage

$size = '{0:N1} MB' -f ((Get-Item -LiteralPath $zip).Length / 1MB)
Write-Host ''
Write-Host "  Made $zip" -ForegroundColor Green
Write-Host "  $count files, $size. On the other computer: unzip it, open the folder, double-click setup.bat."
if (-not $NoExplorer) { Start-Process explorer.exe -ArgumentList "/select,`"$zip`"" }
