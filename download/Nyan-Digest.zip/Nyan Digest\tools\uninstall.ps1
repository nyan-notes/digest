# Nyan Digest uninstall: run it through uninstall.bat (double-click).
# Removes this folder (the app, its Python packages, Whisper models, downloads and history) and the desktop
# shortcut. Your reads are kept unless you say otherwise: if they're inside this folder they're moved to
# Documents\Nyan Digest reads first. Python, ffmpeg, Node.js and the AI writer stay installed (other apps may
# use them); the end of the run says how to remove them.
#   -Yes            answer every question with its default (keep the reads, no prompts)
#   -KeepReadsTo    where to move the reads (default: Documents\Nyan Digest reads)
#   -NoDelete       do everything except deleting this folder (for testing)
param([switch]$Yes, [string]$KeepReadsTo = '', [switch]$NoDelete)
# (ASCII only in this file: Windows PowerShell 5.1 misreads other characters in scripts without a BOM.)

$ErrorActionPreference = 'Continue'
$root = Split-Path -Parent $PSScriptRoot
$host.UI.RawUI.WindowTitle = 'Nyan Digest uninstall'
function Say($msg, $color = 'Gray') { Write-Host $msg -ForegroundColor $color }
function Ok($msg) { Write-Host "  ok: $msg" -ForegroundColor Green }
function Warn($msg) { Write-Host "  ! $msg" -ForegroundColor Yellow }
function Leave($code) { if (-not $Yes) { Read-Host '  Press Enter to close' | Out-Null }; exit $code }
function Ask($question, $default = 'y') {
    if ($Yes) { return $default -eq 'y' }
    $hint = if ($default -eq 'y') { '[Y/n]' } else { '[y/N]' }
    $a = Read-Host "  $question $hint"
    if ([string]::IsNullOrWhiteSpace($a)) { return $default -eq 'y' }
    return $a.Trim().ToLower().StartsWith('y')
}

if (-not (Test-Path (Join-Path $root 'scripts\digest.py'))) { Say "This doesn't look like a Nyan Digest folder: $root" 'Red'; Leave 1 }

Clear-Host
Say ''
Say '  Uninstall Nyan Digest' 'White'
Say ''
Say "  This removes the Nyan Digest folder:  $root"
Say '  (the app, its Python packages, the speech model, downloads and history)'
Say '  and the Nyan Digest shortcut on your desktop.'
Say '  Your reads are kept unless you choose otherwise.'
Say ''
if (-not $Yes -and -not (Ask 'Uninstall Nyan Digest?' 'n')) { Say '  Nothing was changed.'; Leave 0 }

# 1. Stop the app and the worker if they're running from this folder
$procs = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $_.ProcessId -ne $PID -and $_.Name -in @('python.exe', 'pythonw.exe', 'ffmpeg.exe') -and
    $_.CommandLine -and $_.CommandLine -like "*$root*"
}
foreach ($p in $procs) { try { Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop } catch {} }
if ($procs) { Start-Sleep -Seconds 2; Ok "stopped the app ($(@($procs).Count) process(es))" } else { Ok 'the app is not running' }

# 2. The reads
$readsDir = $null
$vpy = Join-Path $root '.venv\Scripts\python.exe'
if (Test-Path $vpy) {
    $readsDir = & $vpy -c "import sys; sys.path.insert(0, r'$root\scripts'); import digest; print((digest.ROOT / digest.load_config()['reads_dir']).resolve())" 2>$null
}
if (-not $readsDir) { $readsDir = Join-Path $root 'reads' }
$readsDir = $readsDir.Trim()
$inside = $readsDir.TrimEnd('\').StartsWith($root.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)
$count = 0
if (Test-Path $readsDir) { $count = @(Get-ChildItem -LiteralPath $readsDir -Recurse -Filter '*.md' -File | Where-Object { $_.Name -notlike '_Queue.md*' }).Count }
if (-not $inside) {
    Ok "your reads stay where they are: $readsDir"
} elseif ($count -eq 0) {
    Ok 'no reads to keep'
} elseif (Ask "Keep your $count read(s)? They'll be moved to your Documents folder." 'y') {
    $dest = if ($KeepReadsTo) { $KeepReadsTo } else { Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Nyan Digest reads' }
    if (Test-Path -LiteralPath $dest) { $dest = "$dest (" + (Get-Date -Format 'yyyy-MM-dd HHmm') + ')' }
    try {
        Move-Item -LiteralPath $readsDir -Destination $dest -ErrorAction Stop
        Remove-Item -LiteralPath (Join-Path $dest '_Queue.md') -Force -ErrorAction SilentlyContinue
        Ok "reads moved to: $dest"
    } catch {
        Warn "Couldn't move the reads ($($_.Exception.Message)). Nothing was deleted; close any open read and run uninstall.bat again."
        Leave 1
    }
} else {
    if (-not (Ask "Delete all $count read(s) for good?" 'n')) { Say '  Then nothing was changed. Run uninstall.bat again when you are ready.'; Leave 0 }
    Ok 'reads will be deleted with the folder'
}

# 3. The desktop shortcut (only one that points into this folder)
$lnk = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Nyan Digest.lnk'
if (Test-Path $lnk) {
    $target = (New-Object -ComObject WScript.Shell).CreateShortcut($lnk).TargetPath
    if ($target -like "$root\*") { Remove-Item -LiteralPath $lnk -Force; Ok 'desktop shortcut removed' }
    else { Ok 'the desktop shortcut belongs to another copy: left alone' }
} else { Ok 'no desktop shortcut' }

# 4. What stays installed
Say ''
Say '  These stay installed (other apps may use them). To remove them too:' 'White'
Say '    - Python 3.12, ffmpeg, Node.js: Settings > Apps > Installed apps, uninstall each.'
$npmBin = "$env:APPDATA\npm"
if (Test-Path "$npmBin\gemini.cmd") { Say '    - Gemini CLI: run  npm uninstall -g @google/gemini-cli  (your API key is in %USERPROFILE%\.gemini)' }
if (Test-Path "$npmBin\codex.cmd") { Say '    - Codex: run  npm uninstall -g @openai/codex' }
if ((Test-Path "$env:USERPROFILE\.local\bin\claude.exe") -or (Get-Command claude -ErrorAction SilentlyContinue)) {
    Say '    - Claude Code: search the web for "uninstall Claude Code" (Anthropic docs explain it)'
}
Say ''

# 5. The folder itself: deleted a few seconds after this window closes (a running script can't delete its own folder)
if ($NoDelete) { Ok "kept the folder (-NoDelete): $root"; exit 0 }
if (-not $Yes) { Read-Host '  Press Enter to finish; the folder is deleted right after' | Out-Null }
$cmd = "timeout /t 3 /nobreak >nul & rmdir /s /q `"$root`""
Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', $cmd -WorkingDirectory $env:TEMP -WindowStyle Hidden
Say '  Nyan Digest is uninstalled. Thanks for trying it!' 'Green'
