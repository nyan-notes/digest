"""Nyan Digest: the desktop app. Add videos or files, follow the queue, open past reads in Nyan Notes.

  .venv\\Scripts\\pythonw.exe scripts\\app.py        (the desktop shortcut runs this)

A native window (pywebview, Edge WebView2) showing app/index.html. All the work stays in digest.py and
worker.py: adding = `digest.py add`, progress = work/*/status.json, processing = worker.py, started
hidden when there's something queued. Closing the window doesn't stop the queue.
"""
import ctypes
import json
import os
import re
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

if sys.stdout is None or sys.stderr is None:  # pythonw (the desktop shortcut): no console, so log to a file
    (Path(__file__).resolve().parent.parent / "work").mkdir(exist_ok=True)
    sys.stdout = sys.stderr = open(Path(__file__).resolve().parent.parent / "work" / "app.log", "a",
                                   encoding="utf-8", buffering=1)
sys.path.insert(0, str(Path(__file__).resolve().parent))
import digest
import writers  # noqa: E402
import webview  # noqa: E402
from webview.dom import DOMEventHandler  # noqa: E402

ROOT, WORK, QUEUE = digest.ROOT, digest.WORK, digest.ROOT / "queue"
PY = ROOT / ".venv" / "Scripts" / "python.exe"  # a console python, run hidden: its children (claude, ffmpeg) stay hidden too
ICON = ROOT / "app" / "nyan-digest.ico"
NO_WINDOW = 0x08000000  # CREATE_NO_WINDOW
NYAN_NOTES = Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Nyan Notes" / "NyanNotes.exe"
MEDIA = ("Video and audio (*.mp4;*.mkv;*.mov;*.webm;*.avi;*.m4v;*.mp3;*.m4a;*.wav;*.ogg;*.opus;*.flac;*.aac)",
         "All files (*.*)")


def worker_running():
    """The worker holds a lock on queue/.worker.lock while it runs."""
    import msvcrt
    QUEUE.mkdir(exist_ok=True)
    try:
        with open(QUEUE / ".worker.lock", "a+") as f:
            f.seek(0)
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
            f.seek(0)
            msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
            return False
    except OSError:
        return True


def start_worker():
    if worker_running() or not any(QUEUE.glob("*.json")):
        return
    log = open(WORK / "worker.log", "a", encoding="utf-8")
    subprocess.Popen([str(PY), str(ROOT / "scripts" / "worker.py")], cwd=ROOT, stdout=log,
                     stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, creationflags=NO_WINDOW)


def run_digest(*args):
    r = subprocess.run([str(PY), str(ROOT / "scripts" / "digest.py"), *args], cwd=ROOT, capture_output=True,
                       text=True, encoding="utf-8", errors="replace", creationflags=NO_WINDOW)
    for line in reversed(r.stdout.strip().splitlines()):
        try:
            return json.loads(line)
        except json.JSONDecodeError:
            continue
    return {"ok": False, "error": (r.stderr.strip().splitlines() or ["unknown error"])[-1]}


class Api:
    """Everything the page can ask for. (Attributes starting with _ are hidden from the page.)"""

    def __init__(self):
        self._window = None
        self._meta = {}

    def _meta_for(self, jid):
        p = WORK / jid / "meta.json"
        try:
            m = p.stat().st_mtime
        except OSError:
            return {}
        if jid not in self._meta or self._meta[jid][0] != m:
            self._meta[jid] = (m, digest.read_json(p, {}) or {})
        return self._meta[jid][1]

    def state(self):
        cfg = digest.load_config()
        running = worker_running()
        queued, queued_notes = set(), {}
        for q in sorted(QUEUE.glob("*.json")):  # files are <id>.json or <id>-2.json (a second version waiting)
            job = digest.read_json(q) or {}
            try:
                qid = digest.resolve(job.get("source", ""))[0]
            except Exception:  # noqa: BLE001
                qid = q.stem
            queued.add(qid)
            if job.get("note"):
                queued_notes.setdefault(qid, job["note"])
        jobs = []
        for p in WORK.glob("*/status.json"):
            s = digest.read_json(p)
            if not s:
                continue
            jid = p.parent.name
            meta = self._meta_for(jid)
            rp = s.get("read_path")
            if rp:
                rp = str(Path(rp) if Path(rp).is_absolute() else ROOT / rp)
            versions = []  # every read of this video (Quick / Medium / Auto / Deep), oldest first
            for r in s.get("reads") or ([{"path": s["read_path"], "length": "auto",
                                          "reading_time": s.get("reading_time"), "finished": s.get("updated_at")}]
                                        if s.get("read_path") else []):
                full = Path(r["path"]) if Path(r["path"]).is_absolute() else ROOT / r["path"]
                if full.exists():
                    versions.append({**r, "path": str(full)})
            active = s.get("state") not in ("done", "error")
            jobs.append({
                **{k: s.get(k) for k in ("id", "source", "state", "progress", "message", "error", "folder",
                                         "updated_at", "dismissed")},
                "id": jid,
                "title": s.get("title") or meta.get("title"),
                "channel": meta.get("channel"),
                "duration": digest.fmt_ts(meta["duration"]) if meta.get("duration") else None,
                "read_path": rp if rp and Path(rp).exists() else None,
                "reading_time": s.get("reading_time") or next(
                    iter(re.findall(r"(\d+ min) read", s.get("message") or "")), None),
                "versions": versions,
                "length": s.get("length"),
                # the note being written with now, else the one waiting in the queue
                "note": s.get("note") if s.get("state") in ("downloading", "transcribing", "extracting_frames",
                                                            "writing") else queued_notes.get(jid),
                "in_queue": jid in queued,
                # an active job with no worker alive and not waiting in the queue was cut off (reboot, crash)
                "interrupted": active and not running and jid not in queued,
            })
        jobs.sort(key=lambda j: j.get("updated_at") or "", reverse=True)
        wname, wexe = writers.pick(cfg)
        return {"jobs": jobs, "folders": cfg["folders"], "worker": running,
                "writer": writers.LABEL[wname], "writer_missing": not wexe,
                "lengths": [{"id": k, **v} for k, v in digest.LENGTHS.items()],
                "reads_dir": str((ROOT / cfg["reads_dir"]).resolve())}

    def add(self, items, folder=None, frames=True, length="auto", note=""):
        results = []
        for src in items:
            args = ["add", src, "--length", length or "auto"]
            if (note or "").strip():
                args.append("--note=" + note.strip())  # = form: a note may start with "-"
            if folder:
                args += ["--folder", folder]
            if not frames:
                args.append("--no-frames")
            r = run_digest(*args)
            r["source"] = src
            results.append(r)
        start_worker()
        return results

    def retry(self, jid):
        job = digest.read_json(WORK / jid / "job.json") or digest.read_json(QUEUE / f"{jid}.json")
        st = digest.read_json(WORK / jid / "status.json") or {}
        source = (job or {}).get("source") or st.get("source")
        if not source:
            return {"ok": False, "error": "Can't find what this job was."}
        args = ["add", source, (job or {}).get("style") or st.get("style") or ""]
        args = [a for a in args if a]
        folder = (job or {}).get("folder") or st.get("folder")
        if folder:
            args += ["--folder", folder]
        if (job or {}).get("no_frames"):
            args.append("--no-frames")
        if (job or {}).get("length"):
            args += ["--length", job["length"]]
        if (job or {}).get("note"):
            args.append("--note=" + job["note"])
        r = run_digest(*args)
        start_worker()
        return r

    def new_version(self, jid, length):
        """Another read of a finished video at another length. Transcript and pictures are cached,
        so it goes straight to writing."""
        st = digest.read_json(WORK / jid / "status.json") or {}
        if not st.get("source"):
            return {"ok": False, "error": "Can't find this video's source."}
        args = ["add", st["source"], "--length", length]
        if st.get("folder"):
            args += ["--folder", st["folder"]]
        r = run_digest(*args)
        start_worker()
        return r

    def dismiss(self, jid):
        digest.Status(jid).set(dismissed=True)
        return True

    def remove(self, jid):
        """Take a job that hasn't started out of the queue."""
        q = QUEUE / f"{jid}.json"
        if q.exists():
            q.unlink()
        digest.Status(jid).set(state="error", error="Removed from the queue", message="Removed", dismissed=True)
        return True

    def pick_files(self):
        res = self._window.create_file_dialog(webview.FileDialog.OPEN, allow_multiple=True, file_types=MEDIA)
        return list(res or [])

    def open_read(self, path):
        if not Path(path).exists():
            return False
        if NYAN_NOTES.exists():
            subprocess.Popen([str(NYAN_NOTES), path])
            return True
        try:
            os.startfile(path)  # whatever opens .md files on this computer
        except OSError:  # nothing does: show it in Explorer instead
            subprocess.Popen(["explorer.exe", "/select,", path])
        return True

    def open_folder(self, folder=None):
        reads = (ROOT / digest.load_config()["reads_dir"]).resolve()
        target = reads / folder if folder and (reads / folder).is_dir() else reads
        os.startfile(target)
        return True

    def open_url(self, url):
        if url.startswith(("https://", "http://")):
            webbrowser.open(url)
        return True


def on_loaded(window):
    # files dropped on the window: the page can't see real paths, the window can
    def on_drop(e):
        paths = [f.get("pywebviewFullPath") for f in e.get("dataTransfer", {}).get("files", [])]
        paths = [p for p in paths if p]
        if paths:
            window.evaluate_js(f"addDropped({json.dumps(paths)})")
    try:
        window.dom.document.events.drop += DOMEventHandler(on_drop, True, True)
    except Exception as e:  # noqa: BLE001
        print(f"drag and drop unavailable: {e}", file=sys.stderr)
    # our own icon in the title bar and taskbar (otherwise it's Python's)
    try:
        from System import Action
        from System.Drawing import Icon
        if ICON.exists():
            window.native.Invoke(Action(lambda: setattr(window.native, "Icon", Icon(str(ICON)))))
    except Exception as e:  # noqa: BLE001
        print(f"icon not set: {e}", file=sys.stderr)


def single_instance():
    """-> a held lock, or None if Nyan Digest is already open (then its window is brought to the front).
    Two copies would fight over the same WebView2 data folder and the second one fails to start."""
    import msvcrt
    WORK.mkdir(exist_ok=True)
    f = open(WORK / ".app.lock", "a+")
    try:
        f.seek(0)
        msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        return f
    except OSError:
        f.close()
        user32 = ctypes.windll.user32
        hwnd = user32.FindWindowW(None, "Nyan Digest")
        if hwnd:
            user32.ShowWindow(hwnd, 9)  # SW_RESTORE
            user32.SetForegroundWindow(hwnd)
        return None


def main():
    lock = single_instance()
    if lock is None:
        return
    try:  # its own taskbar group, not Python's
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("NyanDigest.App")
    except Exception:  # noqa: BLE001
        pass
    start_worker()  # resume a queue left from last time
    api = Api()
    # The page is self-contained, so it goes in as text: served as a file, WebView2's cache kept showing
    # an old copy after index.html changed (the note box didn't appear after a restart).
    page = (ROOT / "app" / "index.html").read_text(encoding="utf-8")
    window = webview.create_window("Nyan Digest", html=page, js_api=api,
                                   width=1080, height=780, min_size=(720, 520), background_color="#FFFFFF")
    api._window = window
    window.events.loaded += lambda: on_loaded(window)
    webview.start(private_mode=False, storage_path=str(WORK / ".webview"))


if __name__ == "__main__":
    main()
