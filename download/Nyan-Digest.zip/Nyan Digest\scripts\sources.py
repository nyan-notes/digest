"""Getting media and captions: yt-dlp for YouTube, ffprobe/ffmpeg for local files."""
import html
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

UPDATE_HINT = r"If this looks like a yt-dlp problem, update it first: .venv\Scripts\pip install -U yt-dlp"
YT_PROBLEMS = [
    ("confirm your age", "This video is age-restricted; it can't be fetched without signing in."),
    ("members-only", "This video is for channel members only."),
    ("join this channel", "This video is for channel members only."),
    ("not available in your country", "This video is region-locked."),
    ("not made this video available in your country", "This video is region-locked."),
    ("private video", "This video is private."),
    ("not a bot", "YouTube is asking to confirm this isn't a bot. Try again later, or update yt-dlp."),
    ("unavailable", "This video is unavailable (removed, or a wrong link)."),
    ("premieres in", "This video hasn't premiered yet."),
    ("live event will begin", "This live stream hasn't started yet."),
]


def find_tool(name):
    """ffmpeg/ffprobe: PATH first, then where winget puts them (PATH may be stale in old terminals)."""
    found = shutil.which(name)
    if found:
        return found
    la = Path(os.environ.get("LOCALAPPDATA", ""))
    for c in [la / "Microsoft/WinGet/Links" / f"{name}.exe",
              *la.glob(f"Microsoft/WinGet/Packages/Gyan.FFmpeg*/*/bin/{name}.exe")]:
        if c.exists():
            return str(c)
    raise RuntimeError(f"{name} not found. Install it with: winget install Gyan.FFmpeg (then restart the terminal)")


def explain(err):
    text = re.sub(r"\x1b\[[0-9;]*m", "", str(err)).replace("ERROR: ", "").strip()
    low = text.lower()
    for key, msg in YT_PROBLEMS:
        if key in low:
            return f"{msg} (yt-dlp: {text})"
    return f"YouTube download failed: {text}. {UPDATE_HINT}"


def _ydl(**extra):
    import yt_dlp
    opts = {"quiet": True, "no_warnings": True, "noprogress": True, "noplaylist": True,
            "ffmpeg_location": str(Path(find_tool("ffmpeg")).parent)}
    opts.update(extra)
    return yt_dlp.YoutubeDL(opts)


# ---------- YouTube ----------

def youtube(url, want_captions, allow_auto, log):
    """-> (meta, segments or None, transcript source or None, language or None)"""
    import yt_dlp
    from digest import UserError
    with _ydl(skip_download=True) as y:
        try:
            info = y.extract_info(url, download=False)
        except yt_dlp.utils.DownloadError as e:
            raise UserError(explain(e)) from None
        if info.get("is_live"):
            raise UserError("This is a live stream that's still running; try again once it has ended.")
        lang = info.get("language")
        auto = info.get("automatic_captions") or {}
        # "xx-orig" = auto captions of an original audio track. AI-dubbed videos have one per dubbed
        # language (21 on a test video, Arabic listed first), so the video's own language decides; a lone
        # "-orig" track is only trusted when the language is unknown and there's no choice.
        origs = [k[: -len("-orig")] for k in auto if k.endswith("-orig")]
        if lang:
            orig = next((o for o in origs if _base(o) == _base(lang)), None)
        else:
            orig = origs[0] if len(origs) == 1 else None
        lang = lang or orig
        meta = {
            "source": f"https://youtu.be/{info['id']}",
            "title": info.get("title") or info["id"],
            "channel": info.get("channel") or info.get("uploader"),
            "duration": info.get("duration"),
            "upload_date": info.get("upload_date"),
            "language": lang,
        }
        segs = src = None
        if want_captions:
            pick = pick_captions(info, lang, orig, allow_auto)
            if pick:
                key, tracks, src = pick
                segs = fetch_captions(y, tracks, log)
                if segs:
                    lang = key.split("-")[0] if src == "captions-auto" else key
                    log(f"Using {src} ({key}), {len(segs)} segments")
                else:
                    log(f"{src} ({key}) came back empty; falling back to Whisper")
                    src = None
            else:
                log(f"No usable captions (language {lang!r}); using Whisper")
        meta["language"] = lang
        return meta, segs, src, (lang.split("-")[0] if lang else None)


def _base(code):
    return (code or "").split("-")[0].lower()


def pick_captions(info, lang, orig, allow_auto):
    """Manual subs in the video's language, then its original-language auto captions."""
    subs = {k: v for k, v in (info.get("subtitles") or {}).items() if k != "live_chat"}
    auto = info.get("automatic_captions") or {}
    if not lang and len(subs) == 1:
        lang = next(iter(subs))
    if not lang:
        return None
    for match in (lambda k: k == lang, lambda k: _base(k) == _base(lang)):
        for k in subs:
            if match(k):
                return k, subs[k], "captions-manual"
    if allow_auto:
        for k in [f"{orig}-orig" if orig else None, lang, _base(lang)]:
            if k and k in auto:
                return k, auto[k], "captions-auto"
    return None


def fetch_captions(y, tracks, log):
    by_ext = {t.get("ext"): t["url"] for t in tracks if t.get("url")}
    for ext, parse in (("json3", parse_json3), ("vtt", parse_vtt)):
        if ext in by_ext:
            try:
                return parse(y.urlopen(by_ext[ext]).read().decode("utf-8", "replace"))
            except Exception as e:  # noqa: BLE001 - any failure here just means "try the next way"
                log(f"Caption download ({ext}) failed: {e}")
    return None


def parse_json3(text):
    """YouTube's json3 captions. Auto captions arrive as word groups, without VTT's rolling repeats."""
    out = []
    for ev in json.loads(text).get("events", []):
        t = "".join(s.get("utf8", "") for s in ev.get("segs") or []).replace("\n", " ").strip()
        if not t:
            continue
        start = ev.get("tStartMs", 0) / 1000
        out.append({"start": round(start, 2), "end": round(start + ev.get("dDurationMs", 0) / 1000, 2),
                    "text": re.sub(r"\s+", " ", t), "speaker": None})
    for a, b in zip(out, out[1:]):  # auto captions overlap; clip each at the next one's start
        a["end"] = min(a["end"], b["start"]) if b["start"] > a["start"] else a["end"]
    return out


def _vtt_time(t):
    h, m, s = (["0"] + t.strip().replace(",", ".").split(":"))[-3:]
    return int(h) * 3600 + int(m) * 60 + float(s)


def parse_vtt(text):
    """WebVTT, with auto captions' rolling duplicate lines removed."""
    out, recent = [], []
    for block in re.split(r"\r?\n\s*\r?\n", text):
        lines = block.strip().splitlines()
        i = next((k for k, line in enumerate(lines) if "-->" in line), None)
        if i is None:
            continue
        a, b = lines[i].split("-->")[:2]
        start, end = _vtt_time(a), _vtt_time(b.split()[0])
        if end - start < 0.05:  # the 10 ms "transition" cues just repeat the previous line
            continue
        for line in lines[i + 1:]:
            line = html.unescape(re.sub(r"<[^>]+>", "", line)).strip()
            if not line or line in recent:
                continue
            out.append({"start": round(start, 2), "end": round(end, 2), "text": line, "speaker": None})
            recent = (recent + [line])[-3:]
    return out


def download_audio(url, job, on_msg):
    import yt_dlp
    from digest import UserError

    def hook(d):
        if d.get("status") == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate")
            pct = f" {100 * d.get('downloaded_bytes', 0) / total:.0f}%" if total else ""
            on_msg(f"Downloading audio…{pct}")

    with _ydl(format="bestaudio/best", outtmpl=str(Path(job) / "audio.%(ext)s"), progress_hooks=[hook]) as y:
        try:
            info = y.extract_info(url, download=True)
        except yt_dlp.utils.DownloadError as e:
            raise UserError(explain(e)) from None
        path = Path(y.prepare_filename(info))
    if not path.exists():
        found = [p for p in Path(job).glob("audio.*") if not p.name.endswith((".part", ".ytdl"))]
        if not found:
            raise UserError(f"Audio download finished but no file appeared. {UPDATE_HINT}")
        path = found[0]
    return path


# ---------- local files ----------

def _run(args):
    r = subprocess.run(args, capture_output=True)
    if r.returncode != 0:
        err = r.stderr.decode("utf-8", "replace").strip().splitlines()
        raise RuntimeError(f"{Path(args[0]).stem} failed: {err[-1] if err else r.returncode}")
    return r.stdout.decode("utf-8", "replace")


def local_meta(path):
    from digest import UserError
    try:
        info = json.loads(_run([find_tool("ffprobe"), "-v", "error", "-show_format", "-show_streams",
                                "-of", "json", str(path)]))
    except RuntimeError as e:
        raise UserError(f"Can't read {path}: {e}") from None
    fmt = info.get("format", {})
    tags = {k.lower(): v for k, v in (fmt.get("tags") or {}).items()}
    streams = info.get("streams", [])
    if not any(s.get("codec_type") == "audio" for s in streams):
        raise UserError(f"{path} has no audio track.")
    return {
        "source": str(path),
        "title": tags.get("title") or Path(path).stem,
        "channel": tags.get("artist") or tags.get("album_artist"),
        "duration": float(fmt["duration"]) if fmt.get("duration") else None,
        "has_video": any(s.get("codec_type") == "video" and not (s.get("disposition") or {}).get("attached_pic")
                         for s in streams),
        "language": None,
    }


def extract_audio(path, job):
    out = Path(job) / "audio.ogg"
    tmp = Path(job) / "audio.tmp.ogg"
    _run([find_tool("ffmpeg"), "-nostdin", "-y", "-v", "error", "-i", str(path), "-vn", "-ac", "1",
          "-ar", "16000", "-c:a", "libopus", "-b:a", "32k", str(tmp)])
    os.replace(tmp, out)
    return out
