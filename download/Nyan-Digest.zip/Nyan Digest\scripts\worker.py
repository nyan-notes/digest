"""Queue worker: turns queue/<id>.json jobs into reads, one at a time, oldest first.

  python scripts/worker.py            process the queue, stop when it's empty
  python scripts/worker.py --watch    keep polling for new jobs (Ctrl+C to stop)

Per job: move the job file to work/<id>/job.json, run the mechanical steps (prepare, frames), then
`claude -p "/digest <id> <style>"` for the writing. Status goes through work/<id>/status.json as usual.
A failed job is marked `error` and the worker moves on.
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import digest  # noqa: E402

ROOT, WORK, QUEUE = digest.ROOT, digest.WORK, digest.ROOT / "queue"
PY = sys.executable
CLAUDE_TIMEOUT = 60 * 60  # one read never needs more than this


def say(msg):
    print(f"{time.strftime('%H:%M:%S')}  {msg}", flush=True)


def next_job():
    jobs = []
    for p in QUEUE.glob("*.json"):
        job = digest.read_json(p)
        if job and job.get("source"):  # an unreadable file may still be being written: skip it this round
            jobs.append((job.get("added_at") or "", p.stat().st_mtime, str(p), job))
    if not jobs:
        return None
    _, _, path, job = min(jobs, key=lambda j: j[:3])
    return Path(path), job


def py(*args, timeout=None):
    """Run digest.py; -> (exit code, last JSON object printed or None, stderr)."""
    r = subprocess.run([PY, str(ROOT / "scripts" / "digest.py"), *args], cwd=ROOT, capture_output=True,
                       text=True, encoding="utf-8", errors="replace", timeout=timeout)
    out = None
    for line in reversed(r.stdout.strip().splitlines()):
        try:
            out = json.loads(line)
            break
        except json.JSONDecodeError:
            continue
    return r.returncode, out, r.stderr


YTDLP_STAMP = WORK / ".ytdlp-updated"
YTDLP_EVERY = 7 * 24 * 3600  # YouTube changes often and yt-dlp follows: update weekly
_updated_this_run = False


def update_ytdlp(force=False):
    """pip install -U yt-dlp, at most weekly (or now, once per run, after a download failure).
    Runs inside the worker's lock, so it never swaps yt-dlp under a running download."""
    global _updated_this_run
    if _updated_this_run or (not force and YTDLP_STAMP.exists()
                             and time.time() - YTDLP_STAMP.stat().st_mtime < YTDLP_EVERY):
        return False
    _updated_this_run = True
    say("Updating yt-dlp…")
    try:
        r = subprocess.run([PY, "-m", "pip", "install", "-q", "--disable-pip-version-check", "-U", "yt-dlp"],
                           cwd=ROOT, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300)
        ok = r.returncode == 0
    except subprocess.TimeoutExpired:
        ok = False
    WORK.mkdir(exist_ok=True)
    YTDLP_STAMP.touch()  # even on failure: don't retry on every job
    say("  yt-dlp is up to date" if ok else "  yt-dlp update failed (no network?); carrying on")
    return ok


def looks_like_ytdlp_trouble(error):
    """Failures an update may fix, not ones about the video itself (private, members-only, removed...)."""
    e = (error or "").lower()
    return "youtube download failed" in e or "a bot" in e or "no file appeared" in e


def fail(jid, msg):
    say(f"  ✗ {msg}")
    digest.Status(jid).set(state="error", error=msg, message="Failed", progress=None)


def run_job(path, job, cfg):
    style = job.get("style") or cfg["default_style"]
    try:  # the id comes from the source (same rule as `digest.py add`), whatever the queue file is called
        jid = digest.resolve(job["source"])[0]
    except digest.UserError as e:
        jid = path.stem
        (WORK / jid).mkdir(parents=True, exist_ok=True)
        os.replace(path, WORK / jid / "job.json")
        fail(jid, str(e))
        return False
    wdir = WORK / jid
    wdir.mkdir(parents=True, exist_ok=True)
    os.replace(path, wdir / "job.json")
    say(f"▶ {jid}  {job['source']}  ({style}, {job.get('length') or 'auto'})")

    length = job.get("length") or "auto"
    prepare = ("prepare", job["source"], "--style", style, "--length", length, "--note=" + (job.get("note") or ""),
               *(["--folder", job["folder"]] if job.get("folder") else []))
    code, out, err = py(*prepare)
    if (code != 0 or not (out or {}).get("ok")) and looks_like_ytdlp_trouble((out or {}).get("error")):
        say(f"  download failed ({out['error'][:120]}); updating yt-dlp and trying once more")
        if update_ytdlp(force=True):
            code, out, err = py(*prepare)
    if code != 0 or not out or not out.get("ok"):
        if not (out and out.get("error")):
            fail(jid, f"prepare crashed: {err.strip().splitlines()[-1] if err.strip() else code}")
        else:
            say(f"  ✗ {out['error']}")
        return False
    say(f"  transcript ready: {out['transcript_source']}, {out['duration']}")

    no_frames = job.get("no_frames") or not out.get("frames")
    if not no_frames:
        code, fr, err = py("frames", jid)
        if code == 0 and fr and fr.get("ok"):
            say(f"  {fr['count']} candidate frames")
        else:  # a read without pictures beats no read
            say(f"  frames failed, writing without them: {(fr or {}).get('error') or err.strip()[-200:]}")
            no_frames = True
            digest.Status(jid).set(state="writing", error=None, message="Frames failed; writing without them…")

    claude = shutil.which("claude")
    if not claude:
        fail(jid, "The claude command wasn't found on PATH (needed to write the read).")
        return False
    prompt = f"/digest {jid} {style} --length {length}" + (" --no-frames" if no_frames else "")
    say(f"  writing with Claude ({cfg['headless_model']})…")
    try:
        r = subprocess.run([claude, "-p", prompt, "--model", cfg["headless_model"], "--output-format", "json"],
                           cwd=ROOT, capture_output=True, text=True, encoding="utf-8", errors="replace",
                           timeout=CLAUDE_TIMEOUT)
    except subprocess.TimeoutExpired:
        fail(jid, f"Claude didn't finish within {CLAUDE_TIMEOUT // 60} minutes.")
        return False
    result = {}
    try:
        result = json.loads(r.stdout)
    except json.JSONDecodeError:
        pass
    with open(wdir / "log.txt", "a", encoding="utf-8") as f:
        f.write(f"{digest.now()} claude -p exit {r.returncode}; result: {str(result.get('result', r.stdout))[-2000:]}\n")
        if result.get("permission_denials"):
            f.write(f"{digest.now()} permission denials: {json.dumps(result['permission_denials'])[:2000]}\n")
        if r.stderr.strip():
            f.write(f"{digest.now()} claude stderr: {r.stderr.strip()[-2000:]}\n")

    st = digest.read_json(wdir / "status.json", {})
    if st.get("state") == "done" and st.get("read_path"):
        say(f"  ✓ {st['read_path']}  ({st.get('message', '')})")
        return True
    why = (result.get("result") or r.stderr or r.stdout or "").strip()[-300:]
    if "login" in why.lower() or "logged in" in why.lower():
        why = ("the claude command isn't signed in. Open a terminal, run `claude`, sign in with /login, "
               "then queue the job again. " + why)
    if result.get("permission_denials"):
        why = f"blocked by permissions ({len(result['permission_denials'])} denied tool calls; see log.txt). {why}"
    fail(jid, f"Claude finished without a read: {why or 'no output'}")
    return False


def lock(wait=15):
    """Only one worker at a time (add.bat starts one each time). Windows releases the lock if we die."""
    import msvcrt
    f = open(QUEUE / ".worker.lock", "a+")
    deadline = time.time() + wait
    while True:
        try:
            f.seek(0)
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
            return f
        except OSError:
            if time.time() > deadline:  # a running worker loops until the queue is empty: it gets the job
                f.close()
                return None
            time.sleep(1)


def main():
    ap = argparse.ArgumentParser(description="Digest queue worker")
    ap.add_argument("--watch", action="store_true", help="keep polling for new jobs")
    ap.add_argument("--interval", type=float, default=10, help="seconds between polls with --watch")
    a = ap.parse_args()
    QUEUE.mkdir(exist_ok=True)
    held = lock()
    if held is None:
        say("Another worker is already running; it will pick up the queued jobs.")
        return 0
    if next_job() is not None:
        update_ytdlp()  # weekly, before any download
    done = failed = 0
    say("Worker started" + (" (watching; Ctrl+C to stop)" if a.watch else ""))
    try:
        while True:
            nxt = next_job()
            if nxt is None:
                if not a.watch:
                    break
                time.sleep(a.interval)
                continue
            try:
                ok = run_job(*nxt, digest.load_config())
            except Exception as e:  # noqa: BLE001 - one bad job never stops the worker
                ok = False
                fail(nxt[0].stem, f"{type(e).__name__}: {e}")
            done += ok
            failed += not ok
    except KeyboardInterrupt:
        say("Stopped.")
    say(f"Queue empty. {done} done, {failed} failed.")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
