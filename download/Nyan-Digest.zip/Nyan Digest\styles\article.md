# Style: article

A well-structured article that someone who never saw the source can read instead of watching it.

## Structure
- Organise by **ideas, not chronology**. Group related points even when they came up at
  different times; the section heading carries the timecode of the main occurrence.
- Usually 4–9 sections with short, specific headings that say what the section claims or covers
  ("Why rate limits beat queues here", not "Discussion").
- Open with the TL;DR blockquote (3–5 sentences: the core of it, not a teaser).
- End with **Mentioned** if anything was referenced (books, papers, people, tools, companies,
  links), each with its timecode. Leave it out if there's nothing.

## What to keep
- Every substantive idea, argument, example, number, recommendation and disagreement.
- The reasoning behind claims, not just the claims: "X, because Y" beats "X".
- Concrete examples and anecdotes when they carry the point; compress them to the part that matters.
- Caveats and uncertainty the speakers themselves expressed.

## What to drop
- Greetings, intros, outros, "like and subscribe", sponsor reads, housekeeping.
- Tangents with no content, jokes that carry nothing, repetition (say it once, at its best).

## Frames
- Only frames that carry information the text can't (slides, charts, diagrams, code, on-screen text, a
  physical technique or object). A frame must earn its place: no decoration, no talking heads.
- Place a frame right after the paragraph it illustrates and caption it plainly. Write the paragraph so
  it still makes sense without the picture.

## Diagrams (drawn in text)
Owner 2026-11-16: the read may include diagrams, drawn with text (never an image file). Nyan Notes shows
no HTML and no Mermaid, but it draws code blocks as a framed monospace box, so a diagram is a fenced code
block with the language `diagram`:

````
```diagram
  Rereading ──► feels familiar ──► "I know this" ──► little recall
      │
      └─ instead ─► Self-test ──► effortful recall ──► stronger memory
```
````

- Add one only where structure is the point and a picture beats a paragraph: a process or pipeline, a
  cycle or feedback loop, a hierarchy, a timeline, a decision tree, a before/after. Usually 0–3 per read;
  zero is fine. Quick reads: at most 1. A conversation with no structure gets none.
- Content strictly from the source: the same faithfulness as the body. Label boxes with the source's
  own terms. Never invent steps, numbers or links between ideas the speakers didn't make.
- Draw with box-drawing characters and arrows: `─ │ ┌ ┐ └ ┘ ├ ┤ ┬ ┴ ┼ ► ◄ ▲ ▼`. Keep every line at most
  64 characters wide (wider lines scroll), and align columns with spaces, never tabs.
- Put it right after the paragraph it illustrates; that paragraph must still make sense without it.
  No caption line inside the block; if it needs one, write a short sentence before it.
- A comparison of options or numbers side by side is a normal Markdown table, not a diagram.

## Claude's notes (only when `claude_notes` is true in prepare's output)
Your own voice goes ONLY in these boxes, never in the body. The body stays strictly what the source says.

```
> [!NOTE] Claude's note
> "Fed watch" is CME's FedWatch tool, which turns futures prices into odds of rate moves.
```

- Place a note right after the paragraph it's about. Usually 0–5 per read; zero is fine. Each note is
  1–3 sentences.
- Only three kinds:
  1. **Context the reader needs:** who a person is, what a term or acronym means, which event is meant
     (for example, a name garbled in the audio that you're confident about).
  2. **A disputed or outdated claim:** when a claim is widely contested, contradicted by well-established
     facts, or has changed since the video, say so briefly and neutrally. The claim stays in the body,
     attributed to the speaker. The note adds perspective; it never replaces the claim.
  3. **A useful connection:** a related idea, source or counterpoint that genuinely helps the reader.
- Only what you're confident about from well-established knowledge. If unsure, write no note. Say
  "as of my knowledge" when something may have changed since your training. No links you haven't seen.
- Not for: praise or criticism of the speaker, summaries, restating the body, opinions on whether the
  advice is good, or investment, medical or legal advice of your own.

## Voice
- Attribute views when there are several people ("The host argues…, the guest pushes back…").
  Use names when the transcript makes them clear. Without speaker labels, attribute only when
  it's obvious from context; otherwise "they".
- Plain, dense prose in short paragraphs. Bullets only for real lists (steps, options, items).
- Short direct quotes (one sentence) only when the exact wording matters. Quote exactly.
- No filler ("In this fascinating episode…", "Overall, …"), no conclusion that repeats the body,
  no opinions of your own about the content.
- **Report, don't judge.** The read tells what the source says; it doesn't evaluate it. Never add
  "he gives no evidence", "this is unverified", "the claim seems doubtful". Never omit a claim because
  it looks wrong to you. Attribute it instead ("he says…", "according to her…"), and the reader judges.
  Faithfulness means faithful to the source, not to your own view of the world.
- **Never mention "the transcript"** (or captions) in the read. The reader thinks in terms of the video
  and its speakers. (`[unclear]` marks are the only trace of transcription.)
- **Name people** when the source names them (speaker labels like `[Jesse]`, introductions). "The host"
  only when no name is given.
- **Timecodes:** every section heading has one. Inside the text, add a timecode only for something a
  reader might want to jump to (a key claim, a striking example, a demonstration), at most about one per
  paragraph, and never two in a row. Don't sprinkle them.
