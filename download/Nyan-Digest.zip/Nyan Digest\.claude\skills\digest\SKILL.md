---
name: digest
description: Turn a YouTube video or a local video/audio file into a 5–15 minute Markdown read in reads/. Use when the user runs /digest <url-or-path-or-id> [style].
argument-hint: <youtube-url | file path | job id> [style]
---

# /digest

Arguments: `$ARGUMENTS`
- **Source:** a YouTube URL, a local file path (it may contain spaces, with or without quotes) or a job id
  (a folder name in `work/`).
- **Style (optional):** a word after the source, if `styles/<word>.md` exists. Otherwise use `default_style` from `config.json`.
- **`--no-frames` (optional):** skip step 2b (no images in this read).
- **`--folder <name>` (optional):** put the read in that folder (pass it on to `prepare`).
- **`--length quick|medium|auto|deep` (optional):** how long the read should be (pass it on to `prepare`).

Work from the project root (the folder with PLAN.md). Python is `.venv/Scripts/python.exe`. Run the
commands with the Bash tool, putting the source in single quotes (write a `'` inside it as `'\''`).
Below, `py` means `.venv/Scripts/python.exe scripts/digest.py`.

## 1. Prepare (no thinking needed, Python does it)
1. `py prepare '<source>' --style <style> --check` prints `{"id", "cached"}` instantly.
2. `py prepare '<source>' --style <style>`
   - If `cached` is true, run it normally (it takes about a second).
   - If not, it may take a long time when Whisper is needed: on the laptop's CPU about 1.5× real time,
     so a 1-hour source takes around 40 minutes (captions take seconds). Run it with
     `run_in_background: true` and wait for the completion notification. Don't poll. If the user
     asks how it's going, read `work/<id>/status.json` (`message`, `progress`). Tell the user once that
     the first Whisper run also downloads the model.
3. It prints one JSON line. If `"ok": false`, the status is already `error`. Tell the user the
   `error` in plain words and what to try (for a yt-dlp failure: `.venv\Scripts\pip install -U yt-dlp`),
   then stop.

Fields used below: `id`, `title`, `transcript_txt`, `txt_lines`, `transcript_words`,
`target_words`, `write_in`, `read_path`, `front_matter`, `kind`, `claude_notes`, `frames`, `folder`, `folders`,
`length`, `max_words`, `user_note`.

## 2. Read everything
- **Auto captions: keep them if clean, switch to Whisper if messy** (owner's rule). If `transcript_source`
  is `captions-auto`, judge the first 60 lines before going on. Missing punctuation is normal for auto
  captions and is not "messy" by itself. Messy means frequent wrong or garbled words, nonsense phrases,
  key names or terms mangled throughout, long stretches missing, or a `words_per_minute` far below
  ~100 for a talk or podcast. If messy, say so in one line and re-run step 1 with `--whisper` (same
  source and style; the transcript is replaced). Then continue with the new transcript.
- Read `styles/<style>.md`.
- Read `transcript_txt` **in full**, in chunks of 60 lines (`offset`/`limit`), until you pass `txt_lines`.
  Never write from only part of it. For a very long transcript, first make a short outline of all
  the topics with timecodes as you go, then write the sections from the outline and the relevant parts.

## 2b. Frames (only if `frames` is true and the user didn't pass `--no-frames`)
Pictures from the video, for moments where seeing beats reading. Do this after reading the transcript.
1. `py frames <id> --check` says whether frames are `cached`. Then run `py frames <id>`: in the
   foreground if cached (instant), otherwise with `run_in_background: true` (it downloads the video at
   ≤720p and scans it, which takes a few minutes) and wait for it. If it fails (`"ok": false`), carry on
   without frames and mention it in your final line. It prints JSON:
   `candidates` (each with `n`, `ts`, `file`, `why`, `near` = what's being said around it), `sheets`
   (contact sheets: 12 numbered thumbnails each), `frames_dir`, `max_frames`.
   If `video` is false or `count` is 0, skip the rest of this step.
2. Look at every contact sheet (Read the image). Shortlist the numbers that might carry information,
   then Read those full-size frames (`<frames_dir>/<file>`) to check what they show and read any text on them.
3. **Keep a frame only if it carries information that text can't:** a slide, chart, diagram, table, code,
   on-screen text, a map, or a physical thing, position or technique where the picture explains it.
   **Drop** talking heads, interview shots, b-roll, logos and intro cards, blurry or mid-transition frames,
   and near-duplicates (keep the clearest one). At most `max_frames`, and spend them on the
   **most important** visuals of the whole video (the key concepts, often late in a talk), not the first
   ones you see, and not several of the same kind of chart. A conversation or podcast usually
   gets **zero**: that's a correct result, not a failure.
4. What you see on a kept frame is part of the source: you may use its content (a slide's numbers, a
   diagram's labels) in the read, exactly as shown. Describe only what's visible; never guess beyond it.

## 3. Write the read
Write in the language `write_in` (an ISO code, e.g. `en`, `fr`).

**The owner's note.** If `user_note` is set (or the user said something like it in the chat), it's the
owner's own instruction for this read, written when they added the video: e.g. "the intro is not useful"
(leave the intro out entirely), "focus on the part about sleep" (give that part most of the space; cover
the rest briefly), "he's the guest, not the host", "skip the sponsor". Follow it over the default
coverage rules here and in the style. It changes what you cover and how, never faithfulness: still no
invented facts, and if the note says something the source contradicts (a name, who's speaking), follow
the source. Never mention the note in the read itself. Note that following it may make the read shorter
than `target_words`: that's fine.

**Length.** `length` comes from the user; `max_words` is the ceiling (230 words ≈ 1 minute of reading).
- **auto** (default; owner: "the most valuable read for the reader, even if long", under ~15 min): include
  everything substantive. `target_words` is the usual size; go above it when the content is dense, up to
  `max_words` (3,500).
- **quick** (2–4 min, ≤900 words): only the core ideas and the key takeaways. TL;DR, 2–4 short sections,
  no side examples, Mentioned only if essential. At most 2 frames and 1 Claude's note.
- **medium** (5–10 min, ~1,200–2,300 words): the main ideas with their reasoning and the best examples;
  drop secondary points and repetition.
- **deep** (up to 25 min, ≤5,800 words): keep more examples, nuance, side arguments and disagreements. Still
  never pad: a thin source gets a shorter read.
In every case, stay within the range and never pad a thin source. `finish` reports the reading time; if
it's clearly outside the chosen range, revise before you reply.

Layout:
```
<front_matter exactly as printed: copy it verbatim>

# <title>

> **TL;DR:** 3–5 sentences covering the core of it.

## <Section heading> · [12:34](@12:34)
<body>

![<caption: what the frame shows and why it matters>](@frame:frame-12m34s.jpg)

> ▶ **Worth watching:** [41:10–42:30](@41:10) — <one line: what happens and why text can't carry it>

## Mentioned
- <Book / paper / person / tool / link>: <what it is, one line> · [1:02:03](@1:02:03)
```

**Timecodes:** write every timecode as `[<shown text>](@<h:mm:ss or mm:ss>)`, using the transcript's
`[...]` markers (a time inside a paragraph may be estimated from its position). Never write YouTube URLs
or seconds yourself: `finish` converts the placeholders into real links (YouTube) or plain `▶ 12:34`
(local files). **Every section heading** ends with ` · [time](@time)` where the topic starts.
**Worth watching:** add it only where something is demonstrated whose point is motion, sound or a
physical action (a live demo, a technique, music), with its time range. Most talks and podcasts have none.
**Frames:** put each kept frame on its own line, right after the paragraph it illustrates, as
`![caption](@frame:<file>)` with the `file` name from step 2b. `finish` copies it next to the read and fixes
the path. The caption is one plain sentence that says what's shown ("Slide: revenue by segment, 2019–2024",
"The finishing position of the heel hook"). A frame shows a still moment; when the motion is the point, use
Worth watching as well (or instead).

**Cold opens and montages:** many videos start with a teaser: quick clips from later in the video,
other people, or other videos, often edited together with music. Recognise them (short, disconnected
lines, often repeated later in full, different voices or speakers before any introduction). Don't attribute
them to the host, don't present them as separate points, and don't count them twice (in YouTube captions,
`>>` marks a change of speaker: a cluster of `>>` in the first minute is a strong sign of a montage): use the full version
where it appears later, with that timecode. If a teaser clip comes from someone who never appears later,
leave it out unless it's clearly part of the argument.

**Faithfulness above everything:** no fact, number, name, quote or claim that isn't in the transcript.
The other side of faithfulness: don't fact-check or editorialise. Keep the speakers' claims, even ones
you doubt, attributed to them, and don't comment on evidence (see the style's "Report, don't judge").
Transcripts garble names and jargon. Correct an obvious mis-hearing only when the context makes
the right word certain. Otherwise write what's there followed by `[unclear]`, or leave it out.

**Claude's notes:** if `claude_notes` is true, you may add a few `> [!NOTE] Claude's note` boxes, following
the style's "Claude's notes" section. Your own knowledge goes there and ONLY there; the body stays the
source's. If `claude_notes` is false, add none.

## 4. Self-check before saving
Go through the draft and check every number, name, quote, date and strong claim against the transcript
(use Grep on `transcript_txt` for the key words). Fix or remove anything you can't find support for.
Check that each heading's timecode is where that topic actually starts.
Then re-read each Claude's note on its own: is it one of the three allowed kinds, are you confident it's true,
and did nothing of yours leak into the body? Delete any note you're not sure of.

## 5. Save and finish
1. Write the read to `read_path` with the Write tool (it's UTF-8). Don't create any other file.
2. **Folder.** If `folder` is set (the user chose it), use it. Otherwise pick the one folder from `folders`
   that best fits the read's main subject (the owner's list; `Other` if nothing fits). Don't invent new ones.
3. `py finish <id> '<read_path>' --folder '<folder>'`: moves the read into that folder, converts timecodes
   and frames, fills `reading_time` and sets the status to `done`. It prints the final `read_path`.
   If it reports `problems` (such as a timecode past the end), fix the read at the printed `read_path`
   and run `finish` again with that path.
4. Reply with one line: the final `read_path` (as a link), the folder and the reading time.

If anything fails after prepare, run `py status <id> error --error '<what went wrong>'` and tell the user.
