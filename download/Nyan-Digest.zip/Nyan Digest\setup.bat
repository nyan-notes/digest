@echo off
rem Installs (or updates) Nyan Digest and everything it needs, then opens it.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\setup.ps1" %*
if errorlevel 1 (
  echo.
  echo Setup stopped. Read the message above, fix it, and run setup.bat again.
)
pause
