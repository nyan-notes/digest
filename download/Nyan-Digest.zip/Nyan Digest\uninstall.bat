@echo off
rem Removes Nyan Digest (asks before touching your reads), then deletes this folder.
rem Runs from %TEMP% so this folder is not in use while it is deleted.
set "ND_ROOT=%~dp0"
cd /d "%TEMP%"
powershell -NoProfile -ExecutionPolicy Bypass -File "%ND_ROOT%tools\uninstall.ps1" %*
