"""Who writes the reads: Claude Code (the default), Gemini CLI or Codex, run headless by the worker.

Owner 2026-11-16: friends without Claude Pro should still be able to use the app, with Gemini CLI (free with a
Google account) or Codex (ChatGPT account). OpenCode was tried first: its free models refuse scripted use
("Free models work in OpenCode… subscribe to OpenCode Go"), so it's not offered.

config.json `writer`: "auto" (the first installed of claude, gemini, codex), or one of them by name.
All three follow the same instructions: .claude/skills/digest/SKILL.md. Claude gets it as the /digest skill;
the others get the skill's text in their prompt, on stdin (they start through npm's .cmd wrappers, and cmd.exe
mangles long multi-line arguments).
"""
import os
import re
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ORDER = ("claude", "gemini", "codex")
LABEL = {"claude": "Claude", "gemini": "Gemini", "codex": "Codex"}
SIGN_IN = {
    "claude": "Open a terminal, run `claude`, sign in with /login",
    "gemini": "Run setup.bat again and paste a Gemini API key (free from aistudio.google.com/apikey)",
    "codex": "Open a terminal, run `codex login`",
}


def find(name):
    """The writer's command, or None. Also looks where the installers put it when PATH isn't refreshed yet."""
    hit = shutil.which(name)
    if hit:
        return hit
    extra = [Path(os.environ.get("APPDATA", "")) / "npm", Path.home() / ".local" / "bin"]
    for d in extra:
        for ext in (".cmd", ".exe"):
            p = d / (name + ext)
            if p.exists():
                return str(p)
    return None


def pick(cfg):
    """(name, path) of the writer to use, or (name, None) if the chosen one isn't installed."""
    want = (cfg.get("writer") or "auto").strip().lower()
    if want in ORDER:
        return want, find(want)
    for name in ORDER:
        path = find(name)
        if path:
            return name, path
    return "claude", None


def skill_text(args):
    """SKILL.md without its front matter, with $ARGUMENTS filled in."""
    text = (ROOT / ".claude" / "skills" / "digest" / "SKILL.md").read_text(encoding="utf-8")
    text = re.sub(r"\A---\n.*?\n---\n", "", text, flags=re.S)
    return text.replace("$ARGUMENTS", args)


def prompt_for(name, args):
    return f"""You are the writer for Nyan Digest, an app that turns long videos into reads. You work in the folder
{ROOT}. Do the whole job below on your own, without asking questions: nobody is watching this run.

How these instructions map to your tools:
- "the Bash tool" = your shell tool. Run Python exactly as `.venv/Scripts/python.exe scripts/digest.py <command> ...`
  (that exact prefix, forward slashes), from {ROOT}. Other shell commands are not allowed.
- "Read" (with offset/limit) = your file-reading tool; "Write" = your file-writing tool; "Grep" = your search tool.
  To look at a picture (a contact sheet or a frame), read the image file with your file-reading tool.
- `run_in_background` doesn't apply: prepare and frames have already run, so their commands return in seconds.
- You are not Claude. Wherever the instructions or the style say `> [!NOTE] Claude's note`, write
  `> [!NOTE] Writer's note` instead. Everything else about those notes stays the same.
- Write only the read itself (at `read_path`); don't create or change any other file.

The instructions (arguments: {args}):

{skill_text(args)}"""


# Gemini with a free API key (owner 2026-11-16; Google sign-in no longer works for individuals): 3.5 Flash
# writes better, but answers "high demand" (503) at busy times; Flash-Lite is the fallback.
GEMINI_MODELS = ["gemini-3.5-flash", "gemini-3.1-flash-lite"]


def models(name, cfg):
    """The models to try in order (None = the writer's own default)."""
    if name == "gemini":
        return [cfg["gemini_model"]] if cfg.get("gemini_model") else GEMINI_MODELS
    if name == "codex":
        return [cfg.get("codex_model") or None]
    return [cfg["headless_model"]]


def busy(text):
    """Worth retrying with the next model: overloaded or out of quota."""
    t = (text or "").lower()
    return quota_hit(t) or any(k in t for k in ("503", "unavailable", "high demand", "overloaded"))


def command(name, path, cfg, args, workdir, model=None):
    """(argv, stdin text or None) to run the writer headless from ROOT."""
    if name == "claude":
        return [path, "-p", f"/digest {args}", "--model", model or cfg["headless_model"], "--output-format", "json"], None
    prompt = prompt_for(name, args)
    if name == "gemini":
        argv = [path, "-p", "Do the job described above.", "--approval-mode", "yolo", "-o", "json"]
        if model:
            argv += ["-m", model]
        return argv, prompt  # gemini appends -p to what comes on stdin
    if name == "codex":
        argv = [path, "exec", "--skip-git-repo-check", "-C", str(ROOT), "-s", "workspace-write",
                "-c", 'approval_policy="never"', "-o", str(Path(workdir) / "writer-last-message.txt")]
        if model:
            argv += ["-m", model]
        return argv + ["-"], prompt  # "-": read the prompt from stdin
    raise ValueError(f"unknown writer {name}")


def signed_out(name, text):
    t = (text or "").lower()
    if name == "claude":
        return "login" in t or "logged in" in t
    if name == "gemini":
        return "auth method" in t or "gemini_api_key" in t or "login" in t and "google" in t
    if name == "codex":
        return "401 unauthorized" in t or "not logged in" in t or "codex login" in t
    return False


def quota_hit(text):
    t = (text or "").lower()
    return any(k in t for k in ("quota", "rate limit", "usage limit", "resource_exhausted", "429"))
