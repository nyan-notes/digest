@echo off
rem Add videos to the digest queue, then start the worker.
rem   Double-click: paste a YouTube link (or a file path).
rem   Or drop one or more video/audio files onto this file.
rem Follow progress in reads\_Queue.md (open it in nyan-notes; it updates by itself).
setlocal
cd /d "%~dp0"
set "PY=.venv\Scripts\python.exe"

if "%~1"=="" goto ask
:each
if "%~1"=="" goto run
"%PY%" scripts\digest.py add "%~1"
shift
goto each

:ask
set "SRC="
set /p "SRC=Paste a YouTube link or a file path, then press Enter: "
if not defined SRC goto end
set "SRC=%SRC:"=%"
"%PY%" scripts\digest.py add "%SRC%"

:run
echo.
echo Starting the worker in its own window (it stops when the queue is empty).
start "Digest worker" cmd /c ""%PY%" scripts\worker.py & pause"
:end
endlocal
