@echo off
rem Process the digest queue once, then stop.
cd /d "%~dp0"
".venv\Scripts\python.exe" scripts\worker.py %*
pause
