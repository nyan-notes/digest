"""Whisper (faster-whisper): GPU when it really works, CPU otherwise. Never crashes because of the GPU."""
import ctypes
import os
from pathlib import Path


def _cuda_ready(log):
    try:
        import ctranslate2
        count = ctranslate2.get_cuda_device_count()
    except Exception as e:  # noqa: BLE001
        log(f"CUDA check failed ({e}); using CPU.")
        return False
    if count < 1:
        log("No CUDA device; using CPU.")
        return False
    # requirements-gpu.txt puts cuBLAS/cuDNN DLLs in site-packages/nvidia/*/bin: make them findable.
    try:
        import nvidia
        for base in nvidia.__path__:
            for b in Path(base).glob("*/bin"):
                os.add_dll_directory(str(b))
                os.environ["PATH"] = str(b) + os.pathsep + os.environ.get("PATH", "")
    except ImportError:
        pass
    for dll in ("cublas64_12.dll", "cudnn_ops64_9.dll"):
        try:
            ctypes.WinDLL(dll)
        except OSError as e:
            log(f"CUDA device found but {dll} can't be loaded ({e}); using CPU. "
                r"Fix: .venv\Scripts\pip install -r requirements-gpu.txt")
            return False
    return True


def physical_cores():
    """CPU threads for Whisper = physical cores (benchmarked on the laptop: 10 beat 8 and 16)."""
    import subprocess
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-Command",
                            "(Get-CimInstance Win32_Processor | Measure-Object NumberOfCores -Sum).Sum"],
                           capture_output=True, text=True, timeout=20)
        return max(1, int(r.stdout.strip()))
    except Exception:  # noqa: BLE001
        return max(4, (os.cpu_count() or 8) // 2)


def decode(path):
    """Audio -> 16 kHz mono float32, via ffmpeg. (faster-whisper's own PyAV decoding breaks whenever
    PyAV changes its API, e.g. av 19 + faster-whisper 1.2.1; ffmpeg is already required anyway.)"""
    import subprocess
    import numpy as np
    from sources import find_tool
    r = subprocess.run([find_tool("ffmpeg"), "-nostdin", "-v", "error", "-i", str(path), "-vn",
                        "-ac", "1", "-ar", "16000", "-f", "s16le", "-"], capture_output=True)
    if r.returncode != 0:
        raise RuntimeError("ffmpeg couldn't decode the audio: " + r.stderr.decode("utf-8", "replace")[-300:])
    return np.frombuffer(r.stdout, np.int16).astype(np.float32) / 32768.0


def run(audio, cfg, lang_hint, models_dir, on_progress, log):
    """-> (segments, language, model name, device)"""
    from faster_whisper import WhisperModel
    from faster_whisper.tokenizer import _LANGUAGE_CODES

    lang = (lang_hint or "").split("-")[0].lower() or None
    if lang not in _LANGUAGE_CODES:
        lang = None
    attempts = []
    if _cuda_ready(log):
        attempts.append(("cuda", cfg["whisper_model_gpu"]))
    attempts.append(("cpu", cfg["whisper_model_cpu"]))
    threads = physical_cores()
    on_progress(0.0, "Decoding audio…")
    samples = decode(audio)

    for device, name in attempts:
        where = "GPU" if device == "cuda" else "CPU"
        try:
            on_progress(0.0, f"Loading Whisper {name} on {where} (the first run downloads the model)…")
            model = WhisperModel(name, device=device, compute_type="int8",
                                 cpu_threads=threads if device == "cpu" else 0,
                                 download_root=str(models_dir))
            # beam_size 5 (the accurate setting) on purpose: the owner values quality over speed.
            # beam_size=1 was ~4x faster on the laptop but changed the text.
            seg_iter, info = model.transcribe(samples, language=lang, vad_filter=True, beam_size=5,
                                              condition_on_previous_text=False)
            total = info.duration or 0
            label = f"Transcribing on {where} ({name}, int8)…"
            on_progress(0.0, label)
            out = []
            for s in seg_iter:
                text = s.text.strip()
                if text:
                    out.append({"start": round(s.start, 2), "end": round(s.end, 2), "text": text, "speaker": None})
                on_progress(min(1.0, s.end / total) if total else None, label)
            log(f"Whisper {name} on {where}: {len(out)} segments, language {info.language}")
            return out, info.language, name, device
        except Exception as e:  # noqa: BLE001
            if device == "cuda":
                log(f"GPU transcription failed ({type(e).__name__}: {e}); falling back to CPU.")
                continue
            raise
