"""Digest: the mechanical side (no LLM).

  python scripts/digest.py prepare <url|path|id> [--style S] [--whisper] [--check]
  python scripts/digest.py status  <id> <state> [--message M] [--read-path P] [--error E] [--progress X]
  python scripts/digest.py add     <url|path|id> [style] [--no-frames] [--folder F] [--length quick|medium|auto|deep] [--note TEXT]   (queue it for worker.py)
  python scripts/digest.py frames  <id> [--force] [--check]
  python scripts/digest.py finish  <id> <read-path> [--folder F]
  python scripts/digest.py list
  python scripts/digest.py dashboard   (rewrite reads/_Queue.md; it's also rewritten on every status change)

prepare: resolves the job id, gets a transcript (captions or Whisper, cached in work/<id>/),
         prints one JSON line for the /digest skill.
finish:  turns (@mm:ss) timecode placeholders into links, fills reading_time, marks the job done.
"""
import argparse
import hashlib
import json
import os
import re
import shutil
import sys
import time
import traceback
from datetime import date, datetime
from pathlib import Path
from urllib.parse import quote

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / "work"
STATES = ("queued", "downloading", "transcribing", "extracting_frames", "writing", "done", "error")
DEFAULTS = {
    "reads_dir": "reads",
    "default_style": "article",
    "output_language": "source",
    "prefer_whisper_over_auto_captions": False,
    "whisper_model_cpu": "small",
    "whisper_model_gpu": "medium",
    "keep_audio": False,
    "keep_video": False,
    "max_frames_per_read": 8,
    "claude_notes": True,
    "frames": True,
    "headless_model": "haiku",
    "folders": ["Finance", "Marketing", "R&D", "Health & Fitness", "Self-improvement", "Education", "Other"],
}


# Read lengths (owner, 2026-11-15). Ranges are ceilings, not quotas: a thin source is never padded.
LENGTHS = {
    "quick": {"label": "Quick", "minutes": "2–4", "max_words": 900},
    "medium": {"label": "Medium", "minutes": "5–10", "max_words": 2300},
    "auto": {"label": "Auto", "minutes": "up to 15", "max_words": 3500},
    "deep": {"label": "Deep", "minutes": "up to 25", "max_words": 5800},
}


def length_name(name):
    name = (name or "auto").strip().lower()
    if name not in LENGTHS:
        raise UserError(f"Unknown length '{name}' (use quick, medium, auto or deep)")
    return name


def folder_name(name):
    """A folder from the user's list (case-insensitive match keeps their spelling), else a safe new one."""
    if not name or name.strip().lower() == "auto":
        return None
    for f in load_config()["folders"]:
        if f.lower() == name.strip().lower():
            return f
    return safe_name(name, 40)
WORDS_PER_MIN = 230

sys.modules.setdefault("digest", sys.modules[__name__])  # helpers import UserError from here
for stream in (sys.stdout, sys.stderr):
    if stream is not None:  # None under pythonw (the desktop app)
        stream.reconfigure(encoding="utf-8", errors="replace")
os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")


# ---------- small helpers ----------

def now():
    return datetime.now().astimezone().isoformat(timespec="seconds")


def load_config():
    cfg = dict(DEFAULTS)
    p = ROOT / "config.json"
    if p.exists():
        cfg.update(json.loads(p.read_text(encoding="utf-8")))
    return cfg


def read_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def write_json(path, data):
    """Atomic write: readers never see half a file."""
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8", newline="\n")
    for _ in range(40):  # Windows refuses the swap while a reader has the file open
        try:
            os.replace(tmp, path)
            return
        except PermissionError:
            time.sleep(0.05)
    os.replace(tmp, path)


def rel(path):
    """Path relative to the project if inside it, forward slashes."""
    path = Path(path)
    try:
        return path.resolve().relative_to(ROOT).as_posix()
    except ValueError:
        return str(path)


def fmt_ts(sec, long=False):
    sec = int(sec)
    h, m, s = sec // 3600, sec % 3600 // 60, sec % 60
    return f"{h}:{m:02}:{s:02}" if long or h else f"{m:02}:{s:02}"


def parse_ts(text):
    parts = [int(p) for p in text.strip().split(":")]
    if not 2 <= len(parts) <= 3:
        raise ValueError(text)
    sec = 0
    for p in parts:
        sec = sec * 60 + p
    return sec


def log(job_dir, msg):
    print(msg, file=sys.stderr)
    with open(Path(job_dir) / "log.txt", "a", encoding="utf-8") as f:
        f.write(f"{now()} {msg}\n")


class Status:
    def __init__(self, job_id):
        self.path = WORK / job_id / "status.json"
        self.data = read_json(self.path, {}) or {}
        base = {"id": job_id, "source": None, "title": None, "style": None, "state": "queued",
                "progress": None, "message": "", "read_path": None, "error": None, "updated_at": now()}
        self.data = {**base, **self.data}
        self._last = 0.0

    def set(self, throttle=False, **kw):
        self.data.update(kw)
        if throttle and time.monotonic() - self._last < 2:
            return
        self._last = time.monotonic()
        self.data["updated_at"] = now()
        write_json(self.path, self.data)
        try:
            write_dashboard()
        except Exception as e:  # noqa: BLE001 - the status note is a convenience; it never breaks a job
            print(f"(status note not updated: {e})", file=sys.stderr)


# ---------- the status note (reads/_Queue.md, read live in nyan-notes) ----------

STATE_LABEL = {"queued": "⏸ Queued", "downloading": "⬇ Downloading", "transcribing": "🎙 Transcribing",
               "extracting_frames": "🖼 Frames", "writing": "✍ Writing", "done": "✓ Done", "error": "✗ Failed"}


def _cell(text, limit=160):
    text = re.sub(r"\s+", " ", str(text or "")).replace("|", "–").strip()
    return text[:limit] + ("…" if len(text) > limit else "")


def write_dashboard():
    """Rewrite reads/_Queue.md from all work/*/status.json. nyan-notes reloads it when it changes."""
    reads = (ROOT / load_config()["reads_dir"]).resolve()
    reads.mkdir(parents=True, exist_ok=True)
    jobs = [s for s in (read_json(p) for p in WORK.glob("*/status.json")) if s]
    jobs.sort(key=lambda s: s.get("updated_at") or "", reverse=True)

    def title(s):
        name = _cell(s.get("title") or s.get("source") or s.get("id"), 90)
        src = s.get("source") or ""
        return f"[{name}]({src})" if src.startswith("http") else name

    active = [s for s in jobs if s.get("state") not in ("done", "error")]
    failed = [s for s in jobs if s.get("state") == "error"]
    done = [s for s in jobs if s.get("state") == "done"]
    out = ["# Digest queue", "",
           f"*Updated {datetime.now().strftime('%H:%M:%S')}. This note refreshes by itself while jobs run. "
           "Add videos with `add.bat` (paste a link, or drop files on it).*", ""]
    out += ["## In progress", ""]
    if active:
        out += ["| Video | State | Details |", "|---|---|---|"]
        for s in active:
            state = STATE_LABEL.get(s.get("state"), s.get("state"))
            if isinstance(s.get("progress"), (int, float)):
                state += f" {s['progress'] * 100:.0f}%"
            out.append(f"| {title(s)} | {state} | {_cell(s.get('message'))} |")
    else:
        out.append("Nothing running.")
    if failed:
        out += ["", "## Failed", "", "| Video | What went wrong |", "|---|---|"]
        out += [f"| {title(s)} | {_cell(s.get('error'), 300)} |" for s in failed[:20]]
    out += ["", "## Done", ""]
    if done:
        out += ["| Read | Length | Finished |", "|---|---|---|"]
        for s in done[:50]:
            rp = Path(s.get("read_path") or "")
            rp = rp if rp.is_absolute() else ROOT / rp
            try:
                link = quote(rp.resolve().relative_to(reads).as_posix())
            except ValueError:
                link = None
            name = _cell(s.get("title") or rp.stem, 90)
            cell = f"[{name}]({link})" if link and rp.exists() else name
            out.append(f"| {cell} | {_cell(s.get('reading_time') or (re.findall(r'(\d+ min) read', s.get('message') or '') or [''])[0])} | {(s.get('updated_at') or '')[:16].replace('T', ' ')} |")
    else:
        out.append("No reads yet.")
    path = reads / "_Queue.md"
    tmp = path.with_name("_Queue.md.tmp")
    tmp.write_text("\n".join(out) + "\n", encoding="utf-8", newline="\n")
    for _ in range(40):  # nyan-notes may be reading it: retry the swap briefly
        try:
            os.replace(tmp, path)
            return
        except PermissionError:
            time.sleep(0.05)
    os.replace(tmp, path)


# ---------- job ids ----------

YT_RE = re.compile(r"(?:youtu\.be/|youtube(?:-nocookie)?\.com/(?:watch\?(?:[^#]*&)?v=|shorts/|live/|embed/|v/))"
                   r"([A-Za-z0-9_-]{11})")


def resolve(source):
    """-> (job_id, kind, canonical source). No network."""
    s = source.strip().strip('"').strip("'").strip()
    m = YT_RE.search(s)
    if m:
        return m.group(1), "youtube", f"https://youtu.be/{m.group(1)}"
    p = Path(os.path.expandvars(s)).expanduser()
    if p.is_file():
        p = p.resolve()
        st = p.stat()
        key = f"{str(p).lower()}|{st.st_size}|{int(st.st_mtime)}"
        return hashlib.sha1(key.encode("utf-8")).hexdigest()[:12], "local", str(p)
    meta = read_json(WORK / s / "meta.json") if re.fullmatch(r"[A-Za-z0-9_-]{6,20}", s) else None
    if meta:
        return s, meta["kind"], meta["source"]
    if re.fullmatch(r"[A-Za-z0-9_-]{11}", s):
        return s, "youtube", f"https://youtu.be/{s}"
    if re.match(r"https?://", s):
        raise UserError(f"Only YouTube links are supported: {s}")
    raise UserError(f"Not a YouTube link, an existing file or a known job id: {s}")


class UserError(Exception):
    """An error whose message is already readable."""


# ---------- transcript text ----------

def paragraphs(segs, min_len=30, max_len=60, max_chars=1500):
    out, cur, start, end = [], [], None, 0
    for s in segs:
        t = s["text"].strip()
        if not t:
            continue
        if start is None:
            start = s["start"]
        cur.append(t)
        end = s["end"]
        span = s["end"] - start
        size = sum(len(x) + 1 for x in cur)
        sentence_end = t.endswith((".", "?", "!", "…", '."', '?"', '!"'))
        if (span >= min_len and sentence_end) or span >= max_len or size >= max_chars:
            out.append((start, " ".join(cur)))
            cur, start = [], None
    if cur:
        out.append((start, " ".join(cur)))
    return out


def write_transcript(job_dir, meta, segs, source, language, model=None):
    data = {"language": language, "source": source, "segments": segs}
    if model:
        data["model"] = model
    write_json(job_dir / "transcript.json", data)
    long = (meta.get("duration") or 0) >= 3600
    words = sum(len(s["text"].split()) for s in segs)
    label = transcript_label(data)
    lines = [
        f"# {meta['title']}",
        " · ".join(x for x in [
            f"Channel: {meta['channel']}" if meta.get("channel") else "",
            f"Duration: {fmt_ts(meta.get('duration') or 0, long)}",
            f"Transcript: {label} ({language or '?'})",
            f"Words: {words:,}"] if x),
        f"Source: {meta['source']}",
        "Each paragraph starts with its [timestamp]. No speaker labels.",
        "",
    ]
    lines += [f"[{fmt_ts(t, long)}] {text}" for t, text in paragraphs(segs)]
    (job_dir / "transcript.txt").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")


def transcript_label(tr):
    return f"whisper-{tr.get('model')}" if tr.get("source") == "whisper" else tr.get("source")


# ---------- reads ----------

def safe_name(title, limit=80):
    t = re.sub(r'[<>:"/\\|?*%\x00-\x1f]', "", title or "Untitled")
    t = re.sub(r"\s+", " ", t).strip()
    if len(t) > limit:
        t = t[:limit].rsplit(" ", 1)[0]
    return t.strip(" .") or "Untitled"


def plan_read(meta, style, cfg, length="auto"):
    reads = (ROOT / cfg["reads_dir"]).resolve()
    reads.mkdir(parents=True, exist_ok=True)
    base = f"{date.today():%Y-%m-%d} {safe_name(meta['title'])}" + ("" if length == "auto" else f" ({length})")
    stem, n = base, 1
    while (reads / f"{stem}.md").exists() or (reads / stem).exists():
        n += 1
        stem = f"{base} ({style})" if n == 2 else f"{base} ({style} {n - 1})"
    return reads / f"{stem}.md", quote(stem, safe="") + "/"


def yaml_value(v):
    v = "" if v is None else str(v)
    if v == "" or ": " in v or " #" in v or v[0] in "-?:,[]{}#&*!|>'\"%@`" or v != v.strip():
        return '"' + v.replace("\\", "\\\\").replace('"', '\\"') + '"'
    return v


def front_matter(meta, style, label, length="auto"):
    long = (meta.get("duration") or 0) >= 3600
    rows = [("title", meta["title"]), ("source", meta["source"]), ("channel", meta.get("channel")),
            ("duration", fmt_ts(meta.get("duration") or 0, long)), ("style", style),
            ("length", None if length == "auto" else length),
            ("reading_time", "TBD"), ("transcript", label), ("created", f"{date.today():%Y-%m-%d}")]
    return "---\n" + "".join(f"{k}: {yaml_value(v)}\n" for k, v in rows if v) + "---\n"


# ---------- commands ----------

def cmd_prepare(a):
    cfg = load_config()
    style = a.style or cfg["default_style"]
    if not (ROOT / "styles" / f"{style}.md").exists():
        raise UserError(f"Unknown style '{style}' (no styles/{style}.md)")
    jid, kind, source = resolve(a.source)
    job = WORK / jid
    meta = read_json(job / "meta.json")
    tr = read_json(job / "transcript.json")
    cached = bool(meta and tr and (job / "transcript.txt").exists()
                  and not (a.whisper and tr.get("source") != "whisper"))
    if a.check:
        print(json.dumps({"id": jid, "kind": kind, "cached": cached}))
        return 0

    job.mkdir(parents=True, exist_ok=True)
    st = Status(jid)
    st.set(source=source, style=style, state="queued", progress=None, read_path=None, error=None,
           title=(meta or {}).get("title"), message="Preparing…")
    if a.folder:  # a folder chosen when adding sticks to the job; otherwise Claude picks one
        st.set(folder=folder_name(a.folder))
    if a.length:  # kept until finish, so the writer's own prepare call sees it too
        st.set(length=length_name(a.length))
    if a.note is not None:  # same: the worker always passes it ("" = no note); the writer's prepare doesn't
        st.set(note=a.note.strip() or None)
    try:
        if not cached:
            meta, tr = make_transcript(jid, kind, source, job, cfg, st, a.whisper)
        summary = summarize(jid, meta, tr, style, cfg)
        summary["cached"] = cached
        st.set(state="writing", progress=None, message=f"Transcript ready; writing the read ({style})…")
    except Exception as e:
        msg = str(e) if isinstance(e, UserError) else f"{type(e).__name__}: {e}"
        log(job, traceback.format_exc())
        st.set(state="error", error=msg, message="Failed", progress=None)
        print(json.dumps({"ok": False, "id": jid, "error": msg}, ensure_ascii=False))
        return 1
    print(json.dumps(summary, ensure_ascii=False))
    return 0


def make_transcript(jid, kind, source, job, cfg, st, force_whisper):
    import sources
    import transcribe

    def note(msg):
        log(job, msg)

    segs = tr_source = audio = None
    if kind == "youtube":
        st.set(state="downloading", message="Reading video info…")
        meta, segs, tr_source, lang = sources.youtube(
            source, want_captions=not force_whisper,
            allow_auto=not cfg["prefer_whisper_over_auto_captions"], log=note)
    else:
        st.set(state="downloading", message="Reading file info…")
        meta = sources.local_meta(source)
        lang = None
    meta.update(id=jid, kind=kind)
    write_json(job / "meta.json", meta)
    st.set(title=meta["title"])

    model = None
    if segs is None:
        audio = next((p for p in job.glob("audio.*") if not p.name.endswith((".part", ".ytdl"))), None)
        if audio is None:
            if kind == "youtube":
                st.set(state="downloading", message="Downloading audio…")
                audio = sources.download_audio(
                    source, job, lambda m: st.set(throttle=True, message=m))
            else:
                st.set(state="downloading", message="Extracting audio…")
                audio = sources.extract_audio(source, job)
        st.set(state="transcribing", progress=0.0, message="Starting Whisper…")
        segs, lang, model, _device = transcribe.run(
            audio, cfg, lang, ROOT / "models",
            lambda p, m: st.set(throttle=p not in (None, 0.0), progress=p, message=m), note)
        tr_source = "whisper"
    if not segs:
        raise UserError("The transcript came out empty (no speech found?)")
    write_transcript(job, meta, segs, tr_source, lang, model)
    if audio and not cfg["keep_audio"]:
        Path(audio).unlink(missing_ok=True)
    return meta, read_json(job / "transcript.json")


def summarize(jid, meta, tr, style, cfg):
    job = WORK / jid
    words = sum(len(s["text"].split()) for s in tr["segments"])
    minutes = (meta.get("duration") or 0) / 60
    length = (read_json(job / "status.json") or {}).get("length") or "auto"
    if length == "quick":
        target = min(700, max(300, words // 4))
    elif length == "medium":
        target = 1700
    elif length == "deep":
        target = min(max(round(minutes * 80), 2500), 5000)
    else:
        target = min(max(round(minutes * 45), 1200), 3500)  # ~1 h video -> ~12 min read (owner: 10-15 min)
    target = min(target, max(300, words // 2))  # a short source never gets a read longer than half of it
    target = int(round(target, -2))
    read_path, img_prefix = plan_read(meta, style, cfg, length)
    txt = job / "transcript.txt"
    lang = tr.get("language")
    out_lang = lang if cfg["output_language"] == "source" else cfg["output_language"]
    return {
        "ok": True, "id": jid, "kind": meta["kind"], "title": meta["title"],
        "channel": meta.get("channel"), "duration": fmt_ts(meta.get("duration") or 0),
        "transcript_source": transcript_label(tr), "language": lang, "write_in": out_lang,
        "transcript_txt": rel(txt), "txt_lines": sum(1 for _ in open(txt, encoding="utf-8")),
        "transcript_words": words, "target_words": target,
        "length": length, "max_words": LENGTHS[length]["max_words"],
        "words_per_minute": round(words / minutes) if minutes else None,  # speech is ~120-180; far less = gaps
        "claude_notes": bool(cfg["claude_notes"]),
        "user_note": (read_json(job / "status.json") or {}).get("note"),  # the owner's note for this read
        "folder": (read_json(job / "status.json") or {}).get("folder"),  # null = pick one from `folders`
        "folders": cfg["folders"],
        "frames": bool(cfg["frames"]) and (meta["kind"] == "youtube" or bool(meta.get("has_video"))),
        "read_path": rel(read_path), "image_prefix": img_prefix,
        "front_matter": front_matter(meta, style, transcript_label(tr), length),
    }


def cmd_frames(a):
    """Candidate frames for the writer to judge. Cached in work/<id>/frames/candidates.json."""
    import frames
    cfg = load_config()
    job = WORK / a.id
    meta, tr = read_json(job / "meta.json"), read_json(job / "transcript.json")
    if not (meta and tr):
        raise UserError(f"No transcript for {a.id}: run prepare first")
    cache = job / "frames" / "candidates.json"
    data = None if a.force else read_json(cache)
    if a.check:
        print(json.dumps({"id": a.id, "cached": data is not None}))
        return 0
    if data is None:
        st = Status(a.id)
        st.set(state="extracting_frames", progress=None, message="Getting frames…")
        try:
            if (job / "frames").exists():
                shutil.rmtree(job / "frames")
            data = frames.run(meta, tr, job, cfg, lambda m: st.set(throttle=m.startswith(("Downloading", "Extracting frame")), message=m),
                              lambda m: log(job, m))
        except Exception as e:
            msg = str(e) if isinstance(e, UserError) else f"{type(e).__name__}: {e}"
            log(job, traceback.format_exc())
            st.set(state="error", error=f"Frames: {msg}", message="Failed")
            print(json.dumps({"ok": False, "id": a.id, "error": msg}, ensure_ascii=False))
            return 1
        (job / "frames").mkdir(exist_ok=True)
        write_json(cache, data)
        st.set(state="writing", message=f"{len(data['candidates'])} candidate frames ready; writing the read…")
    fdir = job / "frames"
    print(json.dumps({"ok": True, "id": a.id, "video": data["video"], "count": len(data["candidates"]),
                      "max_frames": cfg["max_frames_per_read"], "frames_dir": rel(fdir),
                      "sheets": [rel(fdir / s) for s in data["sheets"]],
                      "candidates": data["candidates"]}, ensure_ascii=False))
    return 0


def cmd_add(a):
    """Queue a job for worker.py: writes queue/<id>.json (the same file the nyan-notes panel will write)."""
    cfg = load_config()
    style = a.style or cfg["default_style"]
    if not (ROOT / "styles" / f"{style}.md").exists():
        raise UserError(f"Unknown style '{style}' (no styles/{style}.md)")
    jid, kind, source = resolve(a.source)
    queue = ROOT / "queue"
    queue.mkdir(exist_ok=True)
    job = {"source": source, "style": style, "added_at": now()}
    if a.no_frames:
        job["no_frames"] = True
    folder = folder_name(a.folder)
    if folder:
        job["folder"] = folder
    length = length_name(a.length)
    if length != "auto":
        job["length"] = length
    if (a.note or "").strip():
        job["note"] = a.note.strip()
    qfile, n = queue / f"{jid}.json", 1
    while qfile.exists():
        n += 1
        qfile = queue / f"{jid}-{n}.json"
    write_json(qfile, job)
    (WORK / jid).mkdir(parents=True, exist_ok=True)
    st = Status(jid)
    st.set(source=source, style=style, state="queued", progress=None, read_path=None, error=None,
           folder=folder or st.data.get("folder"), dismissed=False,
           message="Waiting in the queue" + ("" if length == "auto" else f" ({LENGTHS[length]['label']} version)"))
    print(json.dumps({"ok": True, "id": jid, "queued": rel(qfile)}, ensure_ascii=False))
    return 0


def cmd_status(a):
    if a.state not in STATES:
        raise UserError(f"state must be one of: {', '.join(STATES)}")
    if not (WORK / a.id).is_dir():
        raise UserError(f"No job {a.id}")
    kw = {"state": a.state}
    for k in ("message", "error", "progress"):
        if getattr(a, k) is not None:
            kw[k] = getattr(a, k)
    if a.read_path:
        kw["read_path"] = rel(ROOT / a.read_path)
    if a.state != "error":
        kw.setdefault("error", None)
    Status(a.id).set(**kw)
    return 0


FRAME_RE = re.compile(r"!\[([^\]\n]*)\]\(@frame:([\w.-]+)\)")
TC_RE = re.compile(r"\[([^\]\n]+)\]\(@(\d{1,2}(?::\d{2}){1,2})\)")


def cmd_finish(a):
    meta = read_json(WORK / a.id / "meta.json")
    if not meta:
        raise UserError(f"No job {a.id}")
    path = Path(a.read_path)
    path = (path if path.is_absolute() else ROOT / path).resolve()
    text = path.read_text(encoding="utf-8").replace("\r\n", "\n")
    duration = meta.get("duration") or 0
    problems = []

    folder = folder_name(a.folder) if a.folder else (read_json(WORK / a.id / "status.json") or {}).get("folder")
    if folder:  # move the read (and its pictures) into reads/<folder>/
        target_dir = (ROOT / load_config()["reads_dir"]).resolve() / folder
        if path.parent != target_dir:
            target_dir.mkdir(parents=True, exist_ok=True)
            base, stem, n = path.stem, path.stem, 1
            while (target_dir / f"{stem}.md").exists() or (target_dir / stem).exists():
                n += 1
                stem = f"{base} ({n})"
            old_imgs, new_path = path.parent / path.stem, target_dir / f"{stem}.md"
            if stem != path.stem:  # already-linked pictures follow the new name
                text = text.replace(f"]({quote(path.stem, safe='')}/", f"]({quote(stem, safe='')}/")
            new_path.write_text(text, encoding="utf-8", newline="\n")
            path.unlink()
            if old_imgs.is_dir():
                shutil.move(str(old_imgs), str(target_dir / stem))
            path = new_path
        fm = re.match(r"---\n.*?\n---\n", text, re.S)
        if fm and not re.search(r"(?m)^folder:", fm.group(0)):
            text = text[:fm.end() - 4] + f"folder: {yaml_value(folder)}\n" + text[fm.end() - 4:]
        elif fm:
            text = re.sub(r"(?m)^folder:.*$", f"folder: {yaml_value(folder)}", text, count=1)

    def link(m):
        label, ts = m.group(1), m.group(2)
        sec = parse_ts(ts)
        if duration and sec > duration + 5:
            problems.append(f"{ts} is past the end ({fmt_ts(duration)})")
        if meta["kind"] == "youtube":
            return f"[{label}](https://youtu.be/{meta['id']}?t={sec})"
        line_start = text.rfind("\n", 0, m.start()) + 1
        return label if "▶" in text[line_start:m.start()] else f"▶ {label}"

    img_dir = path.parent / path.stem
    frames_used = []

    def frame(m):
        caption, name = m.group(1), m.group(2)
        src = WORK / a.id / "frames" / name
        if not src.exists():
            problems.append(f"frame not found: {name}")
            return m.group(0)
        img_dir.mkdir(exist_ok=True)
        shutil.copy2(src, img_dir / name)
        frames_used.append(name)
        return f"![{caption}]({quote(path.stem, safe='')}/{name})"

    text = FRAME_RE.sub(frame, text)
    max_frames = load_config()["max_frames_per_read"]
    if len(frames_used) > max_frames:
        problems.append(f"{len(frames_used)} frames used; the limit is {max_frames}")
    text = TC_RE.sub(link, text)
    leftovers = re.findall(r"\]\(@[^)]*\)", text)
    if leftovers:
        problems.append("unconverted timecodes: " + ", ".join(leftovers[:5]))
    fm = re.match(r"---\n.*?\n---\n", text, re.S)
    body = text[fm.end():] if fm else text
    plain = re.sub(r"!\[[^\]]*\]\([^)]*\)", "", body)
    plain = re.sub(r"\]\([^)]*\)", "]", plain)
    words = len(re.findall(r"\w[\w'’-]*", plain))
    minutes = max(1, round(words / WORDS_PER_MIN))
    if fm:
        head = re.sub(r"(?m)^reading_time:.*$", f"reading_time: {minutes} min", fm.group(0))
        text = head + body
    path.write_text(text, encoding="utf-8", newline="\n")
    st = Status(a.id)
    earlier = next((r for r in st.data.get("reads") or [] if r.get("path") == rel(path)), {})
    length = st.data.get("length") or earlier.get("length") or "auto"  # a re-run keeps the version's length
    if words > LENGTHS[length]["max_words"] * 1.05:
        problems.append(f"{words:,} words ({minutes} min) is over the {LENGTHS[length]['label']} length "
                        f"({LENGTHS[length]['minutes']} min, about {LENGTHS[length]['max_words']:,} words max): "
                        "tighten it and run finish again")
    reads_list = [r for r in st.data.get("reads") or [] if r.get("path") != rel(path)
                  and (ROOT / r.get("path", "")).exists()]
    reads_list.append({"path": rel(path), "length": length, "reading_time": f"{minutes} min", "finished": now()})
    st.set(state="done", read_path=rel(path), progress=None, error=None, folder=folder,
           length=length if problems else None,  # kept while the writer still has to fix the read
           note=st.data.get("note") if problems else None,
           reads=reads_list, reading_time=f"{minutes} min", message=f"Done: {minutes} min read ({words:,} words)")
    print(json.dumps({"ok": not problems, "read_path": rel(path), "words": words,
                      "reading_time": f"{minutes} min", "frames": len(frames_used), "problems": problems},
                     ensure_ascii=False))
    return 0


def cmd_list(_a):
    rows = []
    for p in WORK.glob("*/status.json"):
        s = read_json(p, {})
        rows.append((s.get("updated_at") or "", p.parent.name, s.get("state") or "?", s.get("title") or ""))
    if not rows:
        print("No jobs yet.")
    for upd, jid, state, title in sorted(rows):
        print(f"{upd[:16].replace('T', ' ')}  {jid:<12}  {state:<12}  {title}")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description="Digest: mechanical side (no LLM)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("prepare")
    p.add_argument("source")
    p.add_argument("--style")
    p.add_argument("--whisper", action="store_true", help="ignore captions, transcribe with Whisper")
    p.add_argument("--check", action="store_true", help="only say whether the transcript is cached")
    p.add_argument("--folder", help="folder for the read (default: Claude picks one)")
    p.add_argument("--length", help="quick, medium, auto (default) or deep")
    p.add_argument("--note", help="the owner's note for the writer (\"\" clears it)")
    p = sub.add_parser("status")
    p.add_argument("id")
    p.add_argument("state")
    p.add_argument("--message")
    p.add_argument("--read-path")
    p.add_argument("--error")
    p.add_argument("--progress", type=float)
    p = sub.add_parser("finish")
    p.add_argument("id")
    p.add_argument("read_path")
    p.add_argument("--folder", help="move the read into reads/<folder>/")
    p = sub.add_parser("frames")
    p.add_argument("id")
    p.add_argument("--force", action="store_true", help="redo even if cached")
    p.add_argument("--check", action="store_true", help="only say whether frames are cached")
    p = sub.add_parser("add")
    p.add_argument("source")
    p.add_argument("style", nargs="?")
    p.add_argument("--no-frames", action="store_true")
    p.add_argument("--folder", help="folder for the read (default: Claude picks one)")
    p.add_argument("--length", help="quick, medium, auto (default) or deep")
    p.add_argument("--note", help="a note for the writer, e.g. \"the intro is not useful\"")
    sub.add_parser("list")
    sub.add_parser("dashboard", help="rewrite reads/_Queue.md now")
    a = ap.parse_args(argv)
    try:
        return {"prepare": cmd_prepare, "add": cmd_add, "status": cmd_status, "frames": cmd_frames,
                "finish": cmd_finish, "list": cmd_list,
                "dashboard": lambda _a: write_dashboard() or 0}[a.cmd](a)
    except UserError as e:
        print(json.dumps({"ok": False, "error": str(e)}, ensure_ascii=False))
        return 1


if __name__ == "__main__":
    sys.exit(main())
