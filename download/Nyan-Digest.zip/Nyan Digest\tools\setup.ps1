# Nyan Digest setup: installs everything it needs, then opens the app.
# Run it through setup.bat (double-click). Safe to run again: it skips what's already done,
# so it's also how you update (unzip the new version over the old folder, run setup.bat).
#   -Yes          answer every question with its default (no prompts)
#   -NoShortcut   don't create the desktop shortcut      -NoLaunch   don't open the app at the end
param([switch]$Yes, [switch]$NoShortcut, [switch]$NoLaunch)
# (ASCII only in this file: Windows PowerShell 5.1 misreads other characters in scripts without a BOM.)

$ErrorActionPreference = 'Continue'  # native tools print warnings on stderr; real failures use throw
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
$host.UI.RawUI.WindowTitle = 'Nyan Digest setup'

function Say($msg, $color = 'Gray') { Write-Host $msg -ForegroundColor $color }
function Step($n, $msg) { Write-Host ''; Write-Host "[$n/7] $msg" -ForegroundColor Cyan }
function Ok($msg) { Write-Host "      ok: $msg" -ForegroundColor Green }
function Warn($msg) { Write-Host "      ! $msg" -ForegroundColor Yellow }
function Ask($question, $default = 'y') {
    if ($Yes) { return $default -eq 'y' }
    $hint = if ($default -eq 'y') { '[Y/n]' } else { '[y/N]' }
    $a = Read-Host "      $question $hint"
    if ([string]::IsNullOrWhiteSpace($a)) { return $default -eq 'y' }
    return $a.Trim().ToLower().StartsWith('y')
}
function Refresh-Path { $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User') }
function Has-Winget { [bool](Get-Command winget -ErrorAction SilentlyContinue) }
function Winget-Install($id, $name) {
    if (-not (Has-Winget)) { throw "winget is missing, so $name can't be installed automatically. Install it from the Microsoft Store ('App Installer'), then run setup.bat again." }
    Say "      installing $name (this can take a minute)..."
    & winget install -e --id $id --scope user --silent --accept-package-agreements --accept-source-agreements --disable-interactivity | Out-Null
    if ($LASTEXITCODE -ne 0) {  # some packages refuse --scope user: try the default scope
        & winget install -e --id $id --silent --accept-package-agreements --accept-source-agreements --disable-interactivity | Out-Null
    }
    Refresh-Path
}

Clear-Host
Say ''
Say '  Nyan Digest setup' 'White'
Say '  Turns YouTube videos and video/audio files into short reads.' 'DarkGray'
Say ''
Say '  This installs what Nyan Digest needs (only what is missing):'
Say '    - Python 3.12 and ffmpeg (free, via Windows'' winget)'
Say '    - a writer: Claude Code, Gemini CLI or Codex (you pick)'
Say '    - the app''s own Python packages, inside this folder'
Say '    - a "Nyan Digest" shortcut on your desktop'
Say '  The first time takes 5 to 10 minutes.'
if (-not (Ask 'Continue?')) { Say 'Nothing was changed.'; exit 0 }

# Files from a downloaded zip are marked "from the internet"; unmark ours so Windows doesn't block them.
Get-ChildItem -LiteralPath $root -Recurse -File -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -notlike "$root\.venv\*" } | Unblock-File -ErrorAction SilentlyContinue

# ---------- 1. Python ----------
Step 1 'Python'
function Find-Python {
    foreach ($v in '3.12', '3.13', '3.11') {
        if (Get-Command py -ErrorAction SilentlyContinue) {
            $p = & py "-$v" -c 'import sys; print(sys.executable)' 2>$null
            if ($LASTEXITCODE -eq 0 -and $p) { return $p.Trim() }
        }
        $guess = "$env:LOCALAPPDATA\Programs\Python\Python$($v.Replace('.',''))\python.exe"
        if (Test-Path $guess) { return $guess }
    }
    $cmd = Get-Command python -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source -notlike '*WindowsApps*') {  # skip the Microsoft Store placeholder
        $v = & $cmd.Source -c 'import sys; print("%d.%d" % sys.version_info[:2])' 2>$null
        if ($v -and [version]$v -ge [version]'3.10') { return $cmd.Source }
    }
    return $null
}
$python = Find-Python
if (-not $python) {
    Winget-Install 'Python.Python.3.12' 'Python 3.12'
    $python = Find-Python
    if (-not $python) { throw 'Python was installed but cannot be found yet. Close this window and run setup.bat again.' }
}
Ok ((& $python --version) + " ($python)")

# ---------- 2. ffmpeg ----------
Step 2 'ffmpeg (reads audio and video)'
function Find-Ffmpeg {
    $c = Get-Command ffmpeg -ErrorAction SilentlyContinue
    if ($c) { return $c.Source }
    $link = "$env:LOCALAPPDATA\Microsoft\WinGet\Links\ffmpeg.exe"
    if (Test-Path $link) { return $link }
    $pkg = Get-ChildItem "$env:LOCALAPPDATA\Microsoft\WinGet\Packages\Gyan.FFmpeg*\*\bin\ffmpeg.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($pkg) { return $pkg.FullName }
    return $null
}
$ffmpeg = Find-Ffmpeg
if (-not $ffmpeg) { Winget-Install 'Gyan.FFmpeg' 'ffmpeg'; $ffmpeg = Find-Ffmpeg }
if (-not $ffmpeg) { throw 'ffmpeg could not be installed. Install it with: winget install Gyan.FFmpeg, then run setup.bat again.' }
Ok $ffmpeg

# ---------- 3. The app's packages ----------
Step 3 'Python packages (inside this folder)'
$vpy = "$root\.venv\Scripts\python.exe"
$venvOk = $false
if (Test-Path $vpy) { & $vpy -c 'import sys' 2>$null; $venvOk = ($LASTEXITCODE -eq 0) }
if (-not $venvOk) {  # missing, or copied from another computer (a venv can't be moved): rebuild it
    if (Test-Path "$root\.venv") { Remove-Item -Recurse -Force "$root\.venv" }
    & $python -m venv "$root\.venv"
    if ($LASTEXITCODE -ne 0) { throw 'Could not create the Python environment.' }
}
Say '      installing or updating packages (a few minutes the first time)...'
& $vpy -m pip install --disable-pip-version-check -q --upgrade pip | Out-Null
& $vpy -m pip install --disable-pip-version-check -q -r "$root\requirements.txt"
if ($LASTEXITCODE -ne 0) { throw 'Installing the packages failed. Check your internet connection and run setup.bat again.' }
$gpu = Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | Where-Object { $_.Name -like '*NVIDIA*' } | Select-Object -First 1
if ($gpu) {
    Say "      NVIDIA graphics card found ($($gpu.Name)): adding GPU support for faster transcription..."
    & $vpy -m pip install --disable-pip-version-check -q -r "$root\requirements-gpu.txt"
    if ($LASTEXITCODE -ne 0) { Warn 'GPU support could not be installed; transcription will use the CPU.' }
}
Ok 'packages ready'

# ---------- 4. Where reads go ----------
Step 4 'Your reads folder'
$cfgPath = "$root\config.json"
$current = & $vpy -c "import sys; sys.path.insert(0, r'$root\scripts'); import digest, pathlib; print((digest.ROOT / digest.load_config()['reads_dir']).resolve())"
if ($env:OneDrive -and (Test-Path $env:OneDrive) -and ($current -notlike "$env:OneDrive*")) {
    Say "      Reads are saved in: $current"
    if (Ask 'Keep them in OneDrive instead, so they sync between your computers?' 'n') {
        $target = Join-Path $env:OneDrive 'Nyan Digest reads'
        New-Item -ItemType Directory -Force -Path $target | Out-Null
        & $vpy -c "import json, pathlib; p = pathlib.Path(r'$cfgPath'); c = json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}; c['reads_dir'] = r'$target'; p.write_text(json.dumps(c, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')"
        $current = $target
    }
}
Ok $current

# ---------- 5. The writer (the AI that writes the reads) ----------
# Claude Code (Claude Pro account), Gemini CLI (a free Google account works) or Codex (ChatGPT account).
# The choice goes in config.json "writer"; scripts/writers.py runs it.
Step 5 'The writer (the AI that writes the reads)'
Refresh-Path
$npmBin = "$env:APPDATA\npm"
if ((Test-Path $npmBin) -and ($env:Path -notlike "*$npmBin*")) { $env:Path += ";$npmBin" }
$localBin = "$env:USERPROFILE\.local\bin"
if ((Test-Path $localBin) -and ($env:Path -notlike "*$localBin*")) { $env:Path += ";$localBin" }
$names = @{ claude = 'Claude Code'; gemini = 'Gemini CLI'; codex = 'Codex' }

function Find-Writer($w) {
    foreach ($p in "$npmBin\$w.cmd", "$localBin\$w.exe") { if (Test-Path $p) { return $p } }
    $c = Get-Command $w -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($c) { return $c.Source }
    return $null
}
function Test-Writer($w, $exe) {
    $q = 'Reply with the single word OK.'
    switch ($w) {
        'claude' { return (& $exe -p $q --model haiku 2>&1 | Out-String) }
        'gemini' { return ($q | & $exe -p ' ' -o text 2>&1 | Out-String) }
        'codex'  { return ($q | & $exe exec --skip-git-repo-check -s read-only - 2>&1 | Out-String) }
    }
}
function Signed-Out($w, $out) {
    switch ($w) {
        'claude' { return $out -match 'log ?in|logged in|authenticat' }
        'gemini' { return $out -match 'Auth method|GEMINI_API_KEY|sign in|login' }
        'codex'  { return $out -match '401|Unauthorized|not logged in|codex login' }
    }
}
function Install-Writer($w) {
    if ($w -eq 'claude') {
        try { Invoke-RestMethod https://claude.ai/install.ps1 | Invoke-Expression } catch { Warn "The installer failed: $($_.Exception.Message)" }
    } else {
        if (-not (Get-Command npm -ErrorAction SilentlyContinue)) {
            Winget-Install 'OpenJS.NodeJS.LTS' 'Node.js (needed to install it)'
            foreach ($d in "$env:ProgramFiles\nodejs", "$env:LOCALAPPDATA\Programs\nodejs") {
                if ((Test-Path "$d\npm.cmd") -and ($env:Path -notlike "*$d*")) { $env:Path += ";$d" }
            }
        }
        if (-not (Get-Command npm -ErrorAction SilentlyContinue)) { Warn 'Node.js could not be found. Close this window and run setup.bat again.'; return }
        $pkg = if ($w -eq 'gemini') { '@google/gemini-cli' } else { '@openai/codex' }
        Say "      installing $($names[$w]) (a minute or two)..."
        & npm install -g $pkg 2>&1 | Out-Null
        if (-not (Test-Path $npmBin)) { New-Item -ItemType Directory -Force $npmBin | Out-Null }
        if ($env:Path -notlike "*$npmBin*") { $env:Path += ";$npmBin" }
    }
}

$saved = & $vpy -c "import sys; sys.path.insert(0, r'$root\scripts'); import digest; print(digest.load_config().get('writer', 'auto'))"
$writer = $null
if ($saved -and $saved.Trim() -ne 'auto' -and $names.ContainsKey($saved.Trim())) { $writer = $saved.Trim() }
elseif (Find-Writer 'claude') { $writer = 'claude' }
else {
    Say '      Who should write your reads? It uses your own account with that company:'
    Say '        1  Claude Code  - needs a Claude Pro (or higher) account. The best reads.'
    Say '        2  Gemini CLI   - free: needs a Google account and a free API key (we show you how).'
    Say '        3  Codex        - needs a ChatGPT account.'
    $a = if ($Yes) { '2' } else { Read-Host '      Type 1, 2 or 3 [2]' }
    $writer = switch ($a.Trim()) { '1' { 'claude' } '3' { 'codex' } default { 'gemini' } }
}
Say "      writer: $($names[$writer])"
$exe = Find-Writer $writer
if (-not $exe) {
    if (Ask "Install $($names[$writer]) now?") { Install-Writer $writer; Refresh-Path; if ($env:Path -notlike "*$npmBin*") { $env:Path += ";$npmBin" }; $exe = Find-Writer $writer }
}
& $vpy -c "import json, pathlib; p = pathlib.Path(r'$cfgPath'); c = json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}; c['writer'] = '$writer'; p.write_text(json.dumps(c, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')"
if (-not $exe) {
    Warn "Without a writer, videos are transcribed but not written up. Run setup.bat again to install $($names[$writer])."
} else {
    Say "      checking that $($names[$writer]) is signed in..."
    $out = Test-Writer $writer $exe
    if (Signed-Out $writer $out) {
        Warn "$($names[$writer]) is not signed in yet."
        switch ($writer) {
            'claude' { Say '      A window will open: type /login, follow the steps in your browser, then close that window.' 'White'; $cmd = "& '$exe'" }
            'gemini' {
                # Google sign-in no longer works for individuals in Gemini CLI (2026-11-16): a free API key does.
                Say '      Gemini needs a free API key from Google. Your browser will open Google AI Studio:' 'White'
                Say '        1. Sign in with your Google account, click "Create API key", and copy the key.' 'White'
                Say '        2. In the window that opens, choose "Trust folder", then "Use Gemini API Key",' 'White'
                Say '           paste the key, press Enter, then close that window.' 'White'
                Say '      Keep the key to yourself: it is like a password for your Google AI account.' 'DarkGray'
                if (-not $Yes) { Start-Process 'https://aistudio.google.com/apikey' }
                $cmd = "& '$exe'"
            }
            'codex'  { Say '      A window will open: sign in with your ChatGPT account in your browser, then close that window.' 'White'; $cmd = "& '$exe' login" }
        }
        if (-not $Yes) {
            Start-Process powershell -ArgumentList '-NoExit', '-Command', "Set-Location '$root'; $cmd" -Wait
            $out = Test-Writer $writer $exe
        }
    }
    if ($out -match '\bOK\b') { Ok "$($names[$writer]) is ready" } else { Warn "$($names[$writer]) didn't answer as expected: $($out.Trim())" }
}
if ($writer -ne 'claude') { Say '      To switch writers later: change "writer" in config.json (claude, gemini or codex) and run setup.bat again.' 'DarkGray' }

# ---------- 6. Shortcut ----------
Step 6 'Desktop shortcut'
if ($NoShortcut) { Ok 'skipped' }
else { & powershell -NoProfile -ExecutionPolicy Bypass -File "$root\tools\make-shortcut.ps1" | Out-Null; Ok 'Nyan Digest is on your desktop' }

# ---------- 7. Something to read with ----------
Step 7 'A reader for the digests'
$nyan = "$env:LOCALAPPDATA\Programs\Nyan Notes\NyanNotes.exe"
if (Test-Path $nyan) { Ok 'Nyan Notes is installed' }
else {
    Say '      Reads are Markdown (.md) files. Nyan Notes (free) shows them with pictures and clickable timecodes.'
    if (Ask 'Open the Nyan Notes download page?') { Start-Process 'https://nyan-notes.github.io' }
    Ok 'any Markdown reader works too'
}

Say ''
Say '  All set. Open Nyan Digest from your desktop, paste a YouTube link, and go.' 'Green'
if (-not $NoLaunch) { Start-Process "$root\.venv\Scripts\pythonw.exe" -ArgumentList "`"$root\scripts\app.py`"" -WorkingDirectory $root }
