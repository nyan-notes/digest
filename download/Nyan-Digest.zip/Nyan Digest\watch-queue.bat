@echo off
rem Keep processing the digest queue as jobs arrive (Ctrl+C to stop).
cd /d "%~dp0"
".venv\Scripts\python.exe" scripts\worker.py --watch %*
pause
