@echo off
rem Makes a zip of Nyan Digest to share (asks: for a friend, or for your other computer).
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\make-zip.ps1" %*
pause
