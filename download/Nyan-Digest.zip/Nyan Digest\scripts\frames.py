"""Phase 3: candidate frames, no LLM.

Candidates come from transcript cue phrases ("as you can see", "this slide"...) and from ffmpeg scene changes
(slide changes, cuts). They're merged, capped, extracted as JPEGs (max 1280 px wide) into work/<id>/frames/,
and tiled into numbered contact sheets so the writer can judge them in a few image reads.
"""
import json
import re
import subprocess
from pathlib import Path

from sources import _ydl, explain, find_tool

CUE_RE = re.compile(
    r"\b(as you can see|you can see (?:here|this|that|it|on)|you see (?:here|this|that)|"
    r"this (?:chart|graph|slide|diagram|table|picture|image|photo|map|screen|code|line|curve|example here)|"
    r"on (?:the|my|your|this) screen|look at (?:this|that|the|these|how)|let me show you|i'?ll show you|"
    r"i'?m going to show you|(?:i )?want to show you|i call (?:this|it)|here it is|here we have|here you can see|here'?s (?:the|a|what)|take a look|if you look at|"
    r"as shown|shown here|watch (?:this|how|closely)|like this|like that|this way|"
    # French, Spanish, German, Italian, Portuguese equivalents
    r"comme vous (?:pouvez|le) voy|vous voyez|regardez|voici|sur l'écran|ce (?:graphique|schéma|tableau)|"
    r"cette (?:slide|diapo|image|courbe)|comme ça|"
    r"como (?:pueden|puedes|podéis) ver|mir(?:a|ad|en) (?:esto|aquí|esta)|así|aquí (?:vemos|tenemos)|"
    r"wie (?:sie|ihr|du) (?:hier )?sehen|schau(?:en sie|t)? (?:mal|hier)|so wie hier|"
    r"come (?:potete|puoi) vedere|guarda(?:te)? (?:qui|questo)|"
    r"como (?:vocês|você) (?:podem|pode) ver|olh(?:a|em) (?:isso|aqui))\b",
    re.I)
SCENE_THRESHOLD = 0.3
MERGE_WINDOW = 4.0  # seconds: candidates closer than this are the same moment


def stamp(sec):
    sec = int(sec)
    h, m, s = sec // 3600, sec % 3600 // 60, sec % 60
    return f"{h}h{m:02}m{s:02}s" if h else f"{m:02}m{s:02}s"


def clock(sec):
    sec = int(sec)
    h, m, s = sec // 3600, sec % 3600 // 60, sec % 60
    return f"{h}:{m:02}:{s:02}" if h else f"{m:02}:{s:02}"


def _run(args, check=True):
    r = subprocess.run(args, capture_output=True)
    if check and r.returncode != 0:
        err = r.stderr.decode("utf-8", "replace").strip().splitlines()
        raise RuntimeError(f"ffmpeg failed: {err[-1] if err else r.returncode}")
    return r


def get_video(meta, job, on_msg):
    """-> (path to a video file, downloaded?) or (None, False) when the source has no picture."""
    import yt_dlp
    from digest import UserError
    if meta["kind"] == "local":
        return (Path(meta["source"]), False) if meta.get("has_video") else (None, False)
    existing = [p for p in Path(job).glob("video.*") if not p.name.endswith((".part", ".ytdl"))]
    if existing:
        return existing[0], True

    def hook(d):
        if d.get("status") == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate")
            pct = f" {100 * d.get('downloaded_bytes', 0) / total:.0f}%" if total else ""
            on_msg(f"Downloading video (≤720p, for frames)…{pct}")

    # Video only (no audio needed for frames), so no merging. Plain single files at low res are gone.
    fmt = "bv*[height<=720][ext=mp4]/bv*[height<=720]/b[height<=720]/b"
    with _ydl(format=fmt, outtmpl=str(Path(job) / "video.%(ext)s"), progress_hooks=[hook]) as y:
        try:
            info = y.extract_info(meta["source"], download=True)
        except yt_dlp.utils.DownloadError as e:
            raise UserError(explain(e)) from None
        path = Path(y.prepare_filename(info))
    if not path.exists():
        path = next(p for p in Path(job).glob("video.*") if not p.name.endswith((".part", ".ytdl")))
    return path, True


def scene_changes(video, on_msg):
    """-> [(time, score)] where the picture changes a lot (slides, cuts), from a low-res pass."""
    on_msg("Looking for scene changes…")
    r = _run([find_tool("ffmpeg"), "-nostdin", "-v", "info", "-i", str(video), "-an", "-sn",
              "-vf", f"fps=4,scale=320:-2,select='gt(scene,{SCENE_THRESHOLD})',metadata=print",
              "-f", "null", "-"])
    out, t = [], None
    for line in r.stderr.decode("utf-8", "replace").splitlines():
        m = re.search(r"pts_time:([\d.]+)", line)
        if m:
            t = float(m.group(1))
        m = re.search(r"lavfi\.scene_score=([\d.]+)", line)
        if m and t is not None:
            out.append((t, float(m.group(1))))
            t = None
    return out


def cue_moments(segments):
    out = []
    for s in segments:
        m = CUE_RE.search(s["text"])
        if m:
            out.append((min(s["start"] + 1.5, s["end"]), m.group(0).lower()))
    return out


def merge(scenes, cues, duration, cap):
    items = [{"t": t + 1.0, "score": sc, "why": [f"scene change {sc:.2f}"]} for t, sc in scenes]
    items += [{"t": t, "score": 0.0, "cue": True, "why": [f"says “{c}”"]} for t, c in cues]
    items = [i for i in items if 0 <= i["t"] <= max(0.0, (duration or 1e9) - 0.5)]
    items.sort(key=lambda i: i["t"])
    merged = []
    for i in items:
        if merged and i["t"] - merged[-1]["t"] < MERGE_WINDOW:
            last = merged[-1]
            last["why"] += [w for w in i["why"] if w not in last["why"]]
            last["score"] = max(last["score"], i["score"])
            last["cue"] = last.get("cue") or i.get("cue")
        else:
            merged.append(dict(i))
    if len(merged) > cap:
        # Spread over the whole video: the best moment of each time slice first (cues cluster early, and
        # a talk's key visual is often late), then the strongest of the rest.
        def prio(i):
            return bool(i.get("cue")) and i["score"] > 0, bool(i.get("cue")), i["score"]
        span = duration or merged[-1]["t"] + 1
        slices = {}
        for i in merged:
            slices.setdefault(min(cap - 1, int(i["t"] / span * cap)), []).append(i)
        chosen = [max(v, key=prio) for v in slices.values()]
        rest = sorted((i for i in merged if all(i is not c for c in chosen)), key=prio, reverse=True)
        merged = sorted(chosen + rest[:cap - len(chosen)], key=lambda i: i["t"])
    return merged


def nearby_text(segments, t, before=8, after=12):
    words = [s["text"] for s in segments if s["end"] >= t - before and s["start"] <= t + after]
    text = " ".join(words)
    return text[:300] + ("…" if len(text) > 300 else "")


def extract(video, cands, frames_dir, on_msg):
    ffmpeg = find_tool("ffmpeg")
    frames_dir.mkdir(parents=True, exist_ok=True)
    thumbs = frames_dir / "thumbs"
    thumbs.mkdir(exist_ok=True)
    font = Path("C:/Windows/Fonts/arial.ttf")
    for n, c in enumerate(cands, 1):
        on_msg(f"Extracting frame {n}/{len(cands)}…")
        c["n"] = n
        c["file"] = f"frame-{stamp(c['t'])}.jpg"
        out = frames_dir / c["file"]
        _run([ffmpeg, "-nostdin", "-v", "error", "-y", "-ss", f"{c['t']:.2f}", "-i", str(video),
              "-frames:v", "1", "-vf", "scale='min(1280,iw)':-2", "-q:v", "3", str(out)])
        # numbered thumbnail for the contact sheet
        vf = "scale=320:180:force_original_aspect_ratio=decrease,pad=320:180:(ow-iw)/2:(oh-ih)/2"
        if font.exists():
            label = f"{n}   {clock(c['t'])}".replace(":", r"\:")
            vf += (",drawtext=fontfile='C\\:/Windows/Fonts/arial.ttf':text='" + label +
                   "':x=6:y=6:fontsize=20:fontcolor=white:box=1:boxcolor=black@0.65:boxborderw=4")
        r = _run([ffmpeg, "-nostdin", "-v", "error", "-y", "-i", str(out), "-vf", vf,
                  str(thumbs / f"t-{n:03}.jpg")], check=False)
        if r.returncode != 0:  # labels are a nicety; never fail on them
            _run([ffmpeg, "-nostdin", "-v", "error", "-y", "-i", str(out), "-vf", vf.split(",drawtext")[0],
                  str(thumbs / f"t-{n:03}.jpg")])
        c["ts"] = clock(c["t"])
        c["t"] = round(c["t"], 2)
    sheets = []
    for k, start in enumerate(range(1, len(cands) + 1, 12), 1):
        sheet = frames_dir / f"sheet-{k:02}.jpg"
        count = min(12, len(cands) - start + 1)
        _run([ffmpeg, "-nostdin", "-v", "error", "-y", "-framerate", "1", "-start_number", str(start),
              "-i", str(thumbs / "t-%03d.jpg"),
              "-vf", f"tile=4x3:padding=4:color=white:nb_frames={count}", "-frames:v", "1", str(sheet)])
        sheets.append(sheet)
    return sheets


def run(meta, transcript, job, cfg, on_msg, log):
    """-> dict saved as frames/candidates.json"""
    job = Path(job)
    video, downloaded = get_video(meta, job, on_msg)
    if video is None:
        return {"video": False, "candidates": [], "sheets": []}
    cap = 3 * int(cfg.get("max_frames_per_read", 8))
    scenes = scene_changes(video, on_msg)
    cues = cue_moments(transcript["segments"])
    cands = merge(scenes, cues, meta.get("duration"), cap)
    log(f"Frames: {len(scenes)} scene changes, {len(cues)} cue phrases -> {len(cands)} candidates")
    frames_dir = job / "frames"
    sheets = extract(video, cands, frames_dir, on_msg) if cands else []
    for c in cands:
        c["near"] = nearby_text(transcript["segments"], c["t"])
        c.pop("score", None)
        c.pop("cue", None)
    if downloaded and not cfg.get("keep_video"):
        Path(video).unlink(missing_ok=True)
    return {"video": True, "candidates": cands, "sheets": [s.name for s in sheets]}
